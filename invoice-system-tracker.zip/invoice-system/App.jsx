import { useState, useRef, useCallback, useEffect } from "react";
import {
  LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid,
  Tooltip, ResponsiveContainer, Cell, ReferenceLine
} from "recharts";

const API = "http://localhost:8000";

// ── Helpers ───────────────────────────────────────────────────────────────────
const fmt = (n) =>
  n != null && n !== "—" && !isNaN(Number(n))
    ? Number(n).toLocaleString("en-US", { style: "currency", currency: "USD" })
    : "—";

const statusMeta = (s) => ({
  new:       { label: "NEW",       color: "#38bdf8", bg: "rgba(56,189,248,0.08)",  icon: "✦" },
  increased: { label: "INCREASED", color: "#f87171", bg: "rgba(248,113,113,0.08)", icon: "↑" },
  decreased: { label: "DECREASED", color: "#4ade80", bg: "rgba(74,222,128,0.08)",  icon: "↓" },
  unchanged: { label: "UNCHANGED", color: "#64748b", bg: "rgba(100,116,139,0.08)", icon: "→" },
}[s?.toLowerCase()] || { label: s, color: "#94a3b8", bg: "transparent", icon: "·" });

// ── API calls ─────────────────────────────────────────────────────────────────
async function apiHealth()        { const r = await fetch(`${API}/health`);        return r.json(); }
async function apiItems()         { const r = await fetch(`${API}/items`);          return r.json(); }
async function apiHistory()       { const r = await fetch(`${API}/history`);        return r.json(); }
async function apiItemHistory(id) { const r = await fetch(`${API}/history/${encodeURIComponent(id)}`); return r.json(); }
async function apiUpload(file, invoiceName) {
  const finalName = invoiceName
    ? (invoiceName.endsWith(".pdf") ? invoiceName : `${invoiceName}.pdf`)
    : file.name;
  const renamedFile = new File([file], finalName, { type: file.type });
  const fd = new FormData();
  fd.append("file", renamedFile);
  const r = await fetch(`${API}/upload-invoice`, { method: "POST", body: fd });
  if (!r.ok) { const e = await r.json(); throw new Error(e.detail || "Upload failed"); }
  return r.json();
}

// ── Custom Tooltip ────────────────────────────────────────────────────────────
const CustomTooltip = ({ active, payload, label }) => {
  if (!active || !payload?.length) return null;
  return (
    <div style={{
      background: "#111827", border: "1px solid #1e2530",
      borderRadius: 8, padding: "10px 14px", fontSize: 12,
    }}>
      <div style={{ color: "#64748b", marginBottom: 4 }}>{label}</div>
      {payload.map((p, i) => (
        <div key={i} style={{ color: p.color || "#94a3b8" }}>
          {p.name}: <strong>{fmt(p.value)}</strong>
        </div>
      ))}
    </div>
  );
};

// ── Components ────────────────────────────────────────────────────────────────
function StatusBadge({ status }) {
  const m = statusMeta(status);
  return (
    <span style={{
      display: "inline-flex", alignItems: "center", gap: 4,
      padding: "3px 9px", borderRadius: 4,
      background: m.bg, color: m.color,
      fontSize: 10, fontWeight: 600, letterSpacing: "0.08em",
    }}>
      {m.icon} {m.label}
    </span>
  );
}

function StatCard({ label, value, sub, accent }) {
  return (
    <div style={{
      background: "#0d1117", border: "1px solid #1e2530",
      borderRadius: 10, padding: "18px 20px",
      borderTop: `2px solid ${accent || "#1e2530"}`,
    }}>
      <div style={{ fontSize: 10, textTransform: "uppercase", letterSpacing: "0.1em", color: "#475569", marginBottom: 8 }}>{label}</div>
      <div style={{ fontFamily: "'Playfair Display', serif", fontSize: 30, color: "#f0f6fc", lineHeight: 1 }}>{value}</div>
      {sub && <div style={{ fontSize: 11, color: "#334155", marginTop: 6 }}>{sub}</div>}
    </div>
  );
}

function Spinner({ text }) {
  return (
    <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 14, padding: "60px 0" }}>
      <div style={{
        width: 32, height: 32, borderRadius: "50%",
        border: "2px solid #1e2530", borderTopColor: "#3b82f6",
        animation: "spin 0.7s linear infinite",
      }} />
      <div style={{ fontSize: 12, color: "#475569" }}>{text}</div>
    </div>
  );
}

function EmptyState({ icon, text }) {
  return (
    <div style={{ padding: "56px 0", textAlign: "center", color: "#334155" }}>
      <div style={{ fontSize: 32, marginBottom: 12 }}>{icon}</div>
      <div style={{ fontSize: 13 }}>{text}</div>
    </div>
  );
}

// ── Charts Tab ────────────────────────────────────────────────────────────────
function ChartsTab({ items, history }) {
  const [selectedItem, setSelectedItem] = useState(null);
  const [itemHistory, setItemHistory]   = useState([]);
  const [loadingHist, setLoadingHist]   = useState(false);

  // Top movers — items with biggest price change %
  const topMovers = [...items]
    .filter(it => it["Change %"] && it["Change %"] !== "")
    .map(it => ({
      name: (it["Description"] || "").slice(0, 22) + ((it["Description"] || "").length > 22 ? "…" : ""),
      fullName: it["Description"],
      itemNo: it["Item Number"],
      change: parseFloat(it["Change %"]) || 0,
      current: it["Current Price"],
      previous: it["Previous Price"],
    }))
    .sort((a, b) => Math.abs(b.change) - Math.abs(a.change))
    .slice(0, 10);

  // Price comparison bar chart data — current vs previous
  const comparisonData = [...items]
    .filter(it => it["Previous Price"] && it["Current Price"])
    .map(it => ({
      name: (it["Description"] || "").slice(0, 18) + "…",
      fullName: it["Description"],
      current: Number(it["Current Price"]) || 0,
      previous: Number(it["Previous Price"]) || 0,
    }))
    .slice(0, 12);

  // Load item price history for trend line
  const loadItemHistory = async (itemNo) => {
    setSelectedItem(itemNo);
    setLoadingHist(true);
    try {
      const d = await apiItemHistory(itemNo);
      const hist = (d.history || []).reverse().map((h, i) => ({
        date: h["Date"],
        price: Number(h["New Price"]) || 0,
        invoice: String(h["Invoice Source"] || "").replace(/\.pdf$/i, ""),
        index: i,
      }));
      setItemHistory(hist);
    } catch {
      setItemHistory([]);
    }
    setLoadingHist(false);
  };

  // Summary stats
  const totalIncreased = items.filter(it => {
    const c = parseFloat(it["Change %"]);
    return c > 0;
  }).length;
  const totalDecreased = items.filter(it => {
    const c = parseFloat(it["Change %"]);
    return c < 0;
  }).length;
  const avgChange = items.length
    ? (items.reduce((sum, it) => sum + (parseFloat(it["Change %"]) || 0), 0) / items.length).toFixed(2)
    : 0;
  const biggestRise = topMovers.filter(m => m.change > 0)[0];
  const biggestDrop = topMovers.filter(m => m.change < 0).slice(-1)[0];

  return (
    <div className="fade-up">
      <div style={{ fontFamily: "'Playfair Display', serif", fontSize: 22, color: "#f0f6fc", marginBottom: 24 }}>
        Price Trends & Analytics
      </div>

      {items.length === 0 ? (
        <EmptyState icon="📊" text="No data yet. Upload invoices to see price trends and charts." />
      ) : (
        <>
          {/* Summary cards */}
          <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 14, marginBottom: 28 }}>
            <StatCard label="Total Items"     value={items.length}      sub="in database"          accent="#334155" />
            <StatCard label="Price Increases" value={totalIncreased}    sub="items went up"        accent="#f87171" />
            <StatCard label="Price Decreases" value={totalDecreased}    sub="items went down"      accent="#4ade80" />
            <StatCard label="Avg Change"      value={`${avgChange}%`}   sub="across all items"     accent="#3b82f6" />
          </div>

          {/* Top movers + comparison side by side */}
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16, marginBottom: 24 }}>

            {/* Top movers bar chart */}
            <div style={{ background: "#0d1117", border: "1px solid #1e2530", borderRadius: 10, padding: "20px" }}>
              <div style={{ fontSize: 12, color: "#94a3b8", marginBottom: 4 }}>Top Price Movers</div>
              <div style={{ fontSize: 11, color: "#334155", marginBottom: 16 }}>Items with biggest % change</div>
              {topMovers.length === 0 ? (
                <div style={{ fontSize: 12, color: "#334155", padding: "20px 0", textAlign: "center" }}>
                  Upload a second invoice to see price movements
                </div>
              ) : (
                <ResponsiveContainer width="100%" height={260}>
                  <BarChart data={topMovers} layout="vertical" margin={{ left: 0, right: 20, top: 0, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#1e2530" horizontal={false} />
                    <XAxis type="number" tick={{ fill: "#475569", fontSize: 10 }} tickFormatter={v => `${v}%`} />
                    <YAxis type="category" dataKey="name" tick={{ fill: "#64748b", fontSize: 10 }} width={100} />
                    <Tooltip content={<CustomTooltip />} cursor={{ fill: "rgba(255,255,255,0.03)" }} />
                    <ReferenceLine x={0} stroke="#334155" />
                    <Bar dataKey="change" name="Change %" radius={[0, 4, 4, 0]}>
                      {topMovers.map((entry, i) => (
                        <Cell key={i} fill={entry.change > 0 ? "#f87171" : "#4ade80"} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              )}
            </div>

            {/* Current vs Previous price comparison */}
            <div style={{ background: "#0d1117", border: "1px solid #1e2530", borderRadius: 10, padding: "20px" }}>
              <div style={{ fontSize: 12, color: "#94a3b8", marginBottom: 4 }}>Current vs Previous Price</div>
              <div style={{ fontSize: 11, color: "#334155", marginBottom: 16 }}>Side by side comparison</div>
              {comparisonData.length === 0 ? (
                <div style={{ fontSize: 12, color: "#334155", padding: "20px 0", textAlign: "center" }}>
                  Upload a second invoice to compare prices
                </div>
              ) : (
                <ResponsiveContainer width="100%" height={260}>
                  <BarChart data={comparisonData} margin={{ left: 0, right: 10, top: 0, bottom: 40 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#1e2530" vertical={false} />
                    <XAxis dataKey="name" tick={{ fill: "#475569", fontSize: 9 }} angle={-35} textAnchor="end" interval={0} />
                    <YAxis tick={{ fill: "#475569", fontSize: 10 }} tickFormatter={v => `$${v}`} />
                    <Tooltip content={<CustomTooltip />} cursor={{ fill: "rgba(255,255,255,0.03)" }} />
                    <Bar dataKey="previous" name="Previous" fill="#334155" radius={[3, 3, 0, 0]} />
                    <Bar dataKey="current"  name="Current"  fill="#3b82f6" radius={[3, 3, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              )}
              {/* Legend */}
              <div style={{ display: "flex", gap: 16, justifyContent: "center", marginTop: 8 }}>
                <div style={{ display: "flex", alignItems: "center", gap: 6, fontSize: 11, color: "#475569" }}>
                  <div style={{ width: 10, height: 10, borderRadius: 2, background: "#334155" }} /> Previous
                </div>
                <div style={{ display: "flex", alignItems: "center", gap: 6, fontSize: 11, color: "#475569" }}>
                  <div style={{ width: 10, height: 10, borderRadius: 2, background: "#3b82f6" }} /> Current
                </div>
              </div>
            </div>
          </div>

          {/* Item price trend line */}
          <div style={{ background: "#0d1117", border: "1px solid #1e2530", borderRadius: 10, padding: "20px", marginBottom: 24 }}>
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 16 }}>
              <div>
                <div style={{ fontSize: 12, color: "#94a3b8", marginBottom: 4 }}>Price Trend Over Time</div>
                <div style={{ fontSize: 11, color: "#334155" }}>Select an item below to see its price history</div>
              </div>
              {selectedItem && (
                <div style={{ fontSize: 11, color: "#60a5fa" }}>
                  Showing: {selectedItem}
                </div>
              )}
            </div>

            {loadingHist ? (
              <Spinner text="Loading trend…" />
            ) : selectedItem && itemHistory.length > 0 ? (
              <ResponsiveContainer width="100%" height={200}>
                <LineChart data={itemHistory} margin={{ left: 10, right: 20, top: 10, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#1e2530" />
                  <XAxis dataKey="invoice" tick={{ fill: "#475569", fontSize: 10 }} />
                  <YAxis tick={{ fill: "#475569", fontSize: 10 }} tickFormatter={v => `$${v}`} domain={["auto", "auto"]} />
                  <Tooltip content={<CustomTooltip />} />
                  <Line
                    type="monotone" dataKey="price" name="Price"
                    stroke="#3b82f6" strokeWidth={2}
                    dot={{ fill: "#3b82f6", r: 4 }}
                    activeDot={{ r: 6, fill: "#60a5fa" }}
                  />
                </LineChart>
              </ResponsiveContainer>
            ) : (
              <div style={{ height: 200, display: "flex", alignItems: "center", justifyContent: "center", color: "#334155", fontSize: 13 }}>
                {selectedItem ? "No history found for this item" : "Click an item below to see its price trend →"}
              </div>
            )}
          </div>

          {/* Clickable items list */}
          <div style={{ border: "1px solid #1e2530", borderRadius: 10, overflow: "hidden" }}>
            <div style={{ background: "#111827", padding: "11px 16px", fontSize: 10, color: "#475569", letterSpacing: "0.1em", textTransform: "uppercase", borderBottom: "1px solid #1e2530" }}>
              Click any item to view its price trend
            </div>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 1, background: "#1e2530" }}>
              {items.map((it, i) => {
                const chg = parseFloat(it["Change %"]) || 0;
                const isSelected = selectedItem === it["Item Number"];
                return (
                  <div
                    key={i}
                    onClick={() => loadItemHistory(it["Item Number"])}
                    style={{
                      background: isSelected ? "#111827" : "#0d1117",
                      padding: "12px 16px", cursor: "pointer",
                      borderLeft: isSelected ? "2px solid #3b82f6" : "2px solid transparent",
                      transition: "all 0.15s",
                    }}
                  >
                    <div style={{ fontSize: 11, color: "#60a5fa", marginBottom: 3 }}>{it["Item Number"]}</div>
                    <div style={{ fontSize: 11, color: "#94a3b8", marginBottom: 6, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
                      {it["Description"]}
                    </div>
                    <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                      <span style={{ fontSize: 12, color: "#f0f6fc", fontWeight: 500 }}>{fmt(it["Current Price"])}</span>
                      {chg !== 0 && (
                        <span style={{ fontSize: 10, color: chg > 0 ? "#f87171" : "#4ade80" }}>
                          {chg > 0 ? "↑" : "↓"} {Math.abs(chg).toFixed(1)}%
                        </span>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </>
      )}
    </div>
  );
}

// ── Main App ──────────────────────────────────────────────────────────────────
export default function InvoiceTracker() {
  const [tab, setTab]               = useState("upload");
  const [health, setHealth]         = useState(null);
  const [items, setItems]           = useState([]);
  const [history, setHistory]       = useState([]);
  const [lastResult, setLastResult] = useState(null);
  const [loading, setLoading]       = useState(false);
  const [loadingText, setLoadingText] = useState("");
  const [error, setError]           = useState(null);
  const [dragging, setDragging]     = useState(false);
  const [invoiceName, setInvoiceName] = useState("");
  const [selectedFile, setSelectedFile] = useState(null);
  const [search, setSearch]         = useState("");
  const [selectedItem, setSelectedItem] = useState(null);
  const [itemHistory, setItemHistory]   = useState([]);
  const fileRef = useRef();

  useEffect(() => {
    apiHealth().then(setHealth).catch(() => setHealth({ status: "error" }));
  }, []);

  useEffect(() => {
    if (tab === "items" || tab === "charts") {
      setLoading(true);
      apiItems()
        .then((d) => setItems(d.items || []))
        .catch(() => setError("Failed to load items"))
        .finally(() => setLoading(false));
    }
    if (tab === "history") {
      setLoading(true);
      apiHistory()
        .then((d) => setHistory(d.history || []))
        .catch(() => setError("Failed to load history"))
        .finally(() => setLoading(false));
    }
  }, [tab]);

  const handleUpload = useCallback(async (file, customName) => {
    if (!file || !file.name.toLowerCase().endsWith(".pdf")) {
      setError("Please select a PDF file.");
      return;
    }
    setError(null);
    setLoading(true);
    setLoadingText("Extracting text from PDF…");
    try {
      setTimeout(() => setLoadingText("Sending to GPT-4o for analysis…"), 1200);
      setTimeout(() => setLoadingText("Updating Excel database…"), 3000);
      const result = await apiUpload(file, customName || invoiceName);
      setLastResult(result);
      setInvoiceName("");
      setSelectedFile(null);
      setTab("changes");
      apiHealth().then(setHealth).catch(() => {});
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
      setLoadingText("");
    }
  }, [invoiceName]);

  const handleDrop = useCallback((e) => {
    e.preventDefault();
    setDragging(false);
    const file = e.dataTransfer.files[0];
    if (file) { setSelectedFile(file); setInvoiceName(file.name.replace(/\.pdf$/i, "")); }
  }, []);

  const openItemHistory = async (itemNo) => {
    setSelectedItem(itemNo);
    try {
      const d = await apiItemHistory(itemNo);
      setItemHistory(d.history || []);
    } catch { setItemHistory([]); }
  };

  const filteredItems = items.filter((it) =>
    !search ||
    String(it["Item Number"] || "").toLowerCase().includes(search.toLowerCase()) ||
    String(it["Description"] || "").toLowerCase().includes(search.toLowerCase())
  );

  const navItems = [
    { id: "upload",  icon: "⬆", label: "Upload Invoice" },
    { id: "changes", icon: "◈", label: "Last Changes" },
    { id: "charts",  icon: "📊", label: "Charts & Trends" },
    { id: "items",   icon: "▤", label: "All Items" },
    { id: "history", icon: "◷", label: "Price History" },
  ];

  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;600&family=JetBrains+Mono:wght@400;500&display=swap');
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
        body { background: #080b10; font-family: 'JetBrains Mono', monospace; }
        @keyframes spin { to { transform: rotate(360deg); } }
        @keyframes fadeUp { from { opacity:0; transform:translateY(12px); } to { opacity:1; transform:translateY(0); } }
        .fade-up { animation: fadeUp 0.35s ease both; }
        ::-webkit-scrollbar { width: 4px; height: 4px; }
        ::-webkit-scrollbar-track { background: #0d1117; }
        ::-webkit-scrollbar-thumb { background: #1e2530; border-radius: 4px; }
        .row-hover:hover td { background: #111827 !important; cursor: pointer; }
      `}</style>

      <div style={{ minHeight: "100vh", background: "#080b10", color: "#e2e8f0" }}>

        {/* Header */}
        <div style={{
          background: "#0d1117", borderBottom: "1px solid #1e2530",
          padding: "0 36px", height: 60,
          display: "flex", alignItems: "center", justifyContent: "space-between",
          position: "sticky", top: 0, zIndex: 100,
        }}>
          <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
            <div style={{
              width: 32, height: 32, borderRadius: 8,
              background: "linear-gradient(135deg, #1d4ed8, #0ea5e9)",
              display: "flex", alignItems: "center", justifyContent: "center", fontSize: 15,
            }}>📋</div>
            <div>
              <span style={{ fontFamily: "'Playfair Display', serif", fontSize: 18, color: "#f0f6fc", fontWeight: 600 }}>Invoice</span>
              <span style={{ fontFamily: "'Playfair Display', serif", fontSize: 18, color: "#3b82f6", fontWeight: 400, fontStyle: "italic" }}>Tracker</span>
            </div>
          </div>
          <div style={{ display: "flex", gap: 24, fontSize: 11, color: "#475569", letterSpacing: "0.06em" }}>
            {health && (
              <>
                <span>DB <span style={{ color: health.status === "ok" ? "#4ade80" : "#f87171" }}>{health.status === "ok" ? "●" : "○"}</span></span>
                <span>Items <span style={{ color: "#94a3b8" }}>{health.total_items ?? "—"}</span></span>
                <span>History <span style={{ color: "#94a3b8" }}>{health.total_history ?? "—"}</span></span>
              </>
            )}
            <a href={`${API}/download`} style={{ color: "#3b82f6", textDecoration: "none", fontSize: 11 }}>↓ Excel</a>
          </div>
        </div>

        <div style={{ display: "flex", height: "calc(100vh - 60px)" }}>

          {/* Sidebar */}
          <div style={{
            width: 210, flexShrink: 0,
            background: "#0d1117", borderRight: "1px solid #1e2530", padding: "20px 0",
          }}>
            <div style={{ fontSize: 9, textTransform: "uppercase", letterSpacing: "0.12em", color: "#334155", padding: "0 20px 10px" }}>Navigation</div>
            {navItems.map((n) => (
              <div key={n.id} onClick={() => { setTab(n.id); setError(null); setSelectedItem(null); }} style={{
                display: "flex", alignItems: "center", gap: 10,
                padding: "10px 20px", fontSize: 11, letterSpacing: "0.05em",
                cursor: "pointer", transition: "all 0.15s",
                color: tab === n.id ? "#60a5fa" : "#475569",
                background: tab === n.id ? "#111827" : "transparent",
                borderLeft: `2px solid ${tab === n.id ? "#3b82f6" : "transparent"}`,
              }}>
                <span style={{ fontSize: 13 }}>{n.icon}</span>{n.label}
              </div>
            ))}

            <div style={{ margin: "20px 12px 0", padding: "12px", background: "#080b10", borderRadius: 8, border: "1px solid #1e2530" }}>
              <div style={{ fontSize: 9, color: "#334155", letterSpacing: "0.1em", marginBottom: 6, textTransform: "uppercase" }}>API</div>
              <div style={{ fontSize: 10, color: health?.status === "ok" ? "#4ade80" : "#f87171" }}>
                {health?.status === "ok" ? "● Connected" : "○ Disconnected"}
              </div>
              <div style={{ fontSize: 10, color: "#334155", marginTop: 4 }}>localhost:8000</div>
            </div>
          </div>

          {/* Content */}
          <div style={{ flex: 1, overflowY: "auto", padding: "28px 36px" }}>

            {error && (
              <div style={{
                background: "rgba(239,68,68,0.08)", border: "1px solid rgba(239,68,68,0.2)",
                borderRadius: 8, padding: "12px 16px", fontSize: 12, color: "#fca5a5", marginBottom: 20,
              }}>⚠ {error}</div>
            )}

            {/* UPLOAD TAB */}
            {tab === "upload" && (
              <div className="fade-up">
                <div style={{ fontFamily: "'Playfair Display', serif", fontSize: 22, color: "#f0f6fc", marginBottom: 24 }}>Upload Invoice</div>
                {loading ? <Spinner text={loadingText || "Processing…"} /> : (
                  <div
                    onDragOver={(e) => { e.preventDefault(); setDragging(true); }}
                    onDragLeave={() => setDragging(false)}
                    onDrop={handleDrop}
                    onClick={() => fileRef.current.click()}
                    style={{
                      border: `1.5px dashed ${dragging ? "#3b82f6" : "#1e2d3d"}`,
                      borderRadius: 14, padding: "64px 40px", textAlign: "center",
                      cursor: "pointer", background: dragging ? "#0f1923" : "#0d1117",
                      transition: "all 0.2s", position: "relative", overflow: "hidden",
                    }}
                  >
                    <div style={{ position: "absolute", inset: 0, background: "radial-gradient(ellipse at 50% 0%, rgba(59,130,246,0.05) 0%, transparent 65%)", pointerEvents: "none" }} />
                    <div style={{ width: 60, height: 60, margin: "0 auto 20px", background: "#111827", border: "1px solid #1e2d3d", borderRadius: 14, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 26 }}>📄</div>
                    <div style={{ fontFamily: "'Playfair Display', serif", fontSize: 20, color: "#f0f6fc", marginBottom: 8 }}>Drop your invoice PDF here</div>
                    <div style={{ fontSize: 12, color: "#475569", lineHeight: 1.8 }}>
                      GPT-4o extracts item number · description · price<br />
                      New items are added · Existing items show price changes
                    </div>
                    <div style={{ marginTop: 24, display: "inline-flex", alignItems: "center", gap: 8, padding: "10px 22px", background: "#1d4ed8", borderRadius: 8, fontSize: 12, color: "#fff" }}
                      onClick={(e) => { e.stopPropagation(); fileRef.current.click(); }}>
                      Browse PDF
                    </div>
                    <input ref={fileRef} type="file" accept="application/pdf" style={{ display: "none" }}
                      onChange={(e) => {
                        const f = e.target.files[0];
                        if (f) { setSelectedFile(f); setInvoiceName(f.name.replace(/\.pdf$/i, "")); }
                      }} />
                  </div>
                )}

                {/* Invoice name input + confirm */}
                {selectedFile && !loading && (
                  <div style={{
                    marginTop: 20, background: "#0d1117",
                    border: "1px solid #3b82f6", borderRadius: 10, padding: "20px 24px",
                  }}>
                    <div style={{ fontSize: 12, color: "#94a3b8", marginBottom: 16, display: "flex", alignItems: "center", gap: 8 }}>
                      📄 <span style={{ color: "#60a5fa" }}>{selectedFile.name}</span>
                      <span style={{ color: "#334155" }}>({(selectedFile.size / 1024).toFixed(1)} KB)</span>
                    </div>

                    <div style={{ marginBottom: 16 }}>
                      <div style={{ fontSize: 11, color: "#475569", marginBottom: 8, textTransform: "uppercase", letterSpacing: "0.08em" }}>
                        Invoice Name / Label
                      </div>
                      <div style={{ display: "flex", gap: 10 }}>
                        <input
                          value={invoiceName}
                          onChange={(e) => setInvoiceName(e.target.value)}
                          placeholder="e.g. Core-Mark Jan 2026, Coca-Cola Week 5..."
                          style={{
                            flex: 1, background: "#111827",
                            border: "1px solid #1e2530", borderRadius: 8,
                            padding: "10px 14px", fontSize: 12,
                            color: "#e2e8f0", outline: "none",
                            fontFamily: "inherit",
                          }}
                          onKeyDown={(e) => e.key === "Enter" && handleUpload(selectedFile)}
                        />
                        {/* Quick vendor presets */}
                        <div style={{ display: "flex", gap: 6 }}>
                          {["Core-Mark", "Coca-Cola", "McLane", "RJ Reynolds"].map(v => (
                            <button key={v} onClick={() => setInvoiceName(`${v} ${new Date().toLocaleDateString("en-US", {month:"short", year:"numeric"})}`)}
                              style={{
                                padding: "0 10px", background: "#111827",
                                border: "1px solid #1e2530", borderRadius: 6,
                                color: "#475569", fontSize: 10, cursor: "pointer",
                                fontFamily: "inherit", whiteSpace: "nowrap",
                              }}>
                              {v}
                            </button>
                          ))}
                        </div>
                      </div>
                    </div>

                    <div style={{ display: "flex", gap: 10 }}>
                      <button
                        onClick={() => handleUpload(selectedFile)}
                        style={{
                          flex: 1, padding: "11px 0",
                          background: "#1d4ed8", color: "#fff",
                          border: "none", borderRadius: 8,
                          fontSize: 12, cursor: "pointer",
                          fontFamily: "inherit", letterSpacing: "0.05em",
                        }}>
                        ⬆ Upload & Process Invoice
                      </button>
                      <button
                        onClick={() => { setSelectedFile(null); setInvoiceName(""); }}
                        style={{
                          padding: "11px 18px", background: "transparent",
                          color: "#475569", border: "1px solid #1e2530",
                          borderRadius: 8, fontSize: 12, cursor: "pointer",
                          fontFamily: "inherit",
                        }}>
                        Cancel
                      </button>
                    </div>
                  </div>
                )}
                <div style={{ marginTop: 28, display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 14 }}>
                  {[
                    { step: "01", title: "Upload PDF", desc: "Drop any invoice PDF into the system" },
                    { step: "02", title: "AI Extracts", desc: "GPT-4o reads and structures all line items" },
                    { step: "03", title: "Track Changes", desc: "Price changes logged to Excel automatically" },
                  ].map((s) => (
                    <div key={s.step} style={{ background: "#0d1117", border: "1px solid #1e2530", borderRadius: 10, padding: "16px 18px" }}>
                      <div style={{ fontSize: 10, color: "#3b82f6", letterSpacing: "0.1em", marginBottom: 6 }}>STEP {s.step}</div>
                      <div style={{ fontSize: 13, color: "#e2e8f0", marginBottom: 4 }}>{s.title}</div>
                      <div style={{ fontSize: 11, color: "#475569", lineHeight: 1.6 }}>{s.desc}</div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* CHANGES TAB */}
            {tab === "changes" && (
              <div className="fade-up">
                <div style={{ fontFamily: "'Playfair Display', serif", fontSize: 22, color: "#f0f6fc", marginBottom: 24 }}>Last Invoice Changes</div>
                {!lastResult ? (
                  <EmptyState icon="◈" text="No invoice processed yet. Upload a PDF to see changes here." />
                ) : (
                  <>
                    <div style={{ background: "#0d1117", border: "1px solid #1e2530", borderRadius: 10, padding: "14px 20px", marginBottom: 20, display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                      <div>
                        <div style={{ fontSize: 12, color: "#94a3b8" }}>📄 {lastResult.invoice}</div>
                        <div style={{ fontSize: 11, color: "#475569", marginTop: 2 }}>{lastResult.pages} page{lastResult.pages !== 1 ? "s" : ""} · {lastResult.total_items} line items extracted</div>
                      </div>
                      <a href={`${API}/download`} style={{ display: "inline-flex", alignItems: "center", gap: 6, padding: "8px 16px", background: "#064e3b", color: "#34d399", border: "1px solid #065f46", borderRadius: 8, fontSize: 11, textDecoration: "none" }}>
                        ↓ Download Excel
                      </a>
                    </div>
                    <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 14, marginBottom: 22 }}>
                      <StatCard label="Total Items"     value={lastResult.total_items}       sub="in this invoice"   accent="#334155" />
                      <StatCard label="New Items"       value={lastResult.summary.new}       sub="added to database" accent="#38bdf8" />
                      <StatCard label="Price Increases" value={lastResult.summary.increased} sub="cost went up"      accent="#f87171" />
                      <StatCard label="Price Decreases" value={lastResult.summary.decreased} sub="cost went down"    accent="#4ade80" />
                    </div>
                    <div style={{ border: "1px solid #1e2530", borderRadius: 10, overflow: "hidden" }}>
                      <table style={{ width: "100%", borderCollapse: "collapse" }}>
                        <thead>
                          <tr style={{ background: "#111827" }}>
                            {["Status", "Item #", "Description", "Old Price", "New Price", "Change", "Matched By"].map((h) => (
                              <th key={h} style={{ textAlign: "left", padding: "11px 16px", fontSize: 10, letterSpacing: "0.1em", textTransform: "uppercase", color: "#475569", borderBottom: "1px solid #1e2530", fontWeight: 500 }}>{h}</th>
                            ))}
                          </tr>
                        </thead>
                        <tbody>
                          {lastResult.changes.map((c, i) => (
                            <tr key={i} style={{ borderBottom: "1px solid #111827" }}>
                              <td style={{ padding: "11px 16px" }}><StatusBadge status={c.status} /></td>
                              <td style={{ padding: "11px 16px", fontSize: 12, color: "#60a5fa" }}>{c.item_number}</td>
                              <td style={{ padding: "11px 16px", fontSize: 12, color: "#e2e8f0", maxWidth: 200 }}>{c.description}</td>
                              <td style={{ padding: "11px 16px", fontSize: 12, color: "#475569", textDecoration: "line-through" }}>{c.old_price != null ? fmt(c.old_price) : "—"}</td>
                              <td style={{ padding: "11px 16px", fontSize: 12, color: c.status === "increased" ? "#f87171" : c.status === "decreased" ? "#4ade80" : "#94a3b8" }}>{fmt(c.new_price)}</td>
                              <td style={{ padding: "11px 16px", fontSize: 12 }}>
                                {c.change_pct != null ? (
                                  <span style={{ color: c.change_pct > 0 ? "#f87171" : c.change_pct < 0 ? "#4ade80" : "#64748b" }}>
                                    {c.change_pct > 0 ? "+" : ""}{c.change_pct.toFixed(2)}%
                                  </span>
                                ) : "—"}
                              </td>
                              <td style={{ padding: "11px 16px" }}>
                                <span style={{ fontSize: 10, padding: "2px 8px", borderRadius: 4, background: c.match_type === "description" ? "rgba(251,191,36,0.1)" : "#111827", color: c.match_type === "description" ? "#fbbf24" : "#475569", border: `1px solid ${c.match_type === "description" ? "rgba(251,191,36,0.2)" : "#1e2530"}` }}>
                                  {c.match_type === "description" ? "⚡ desc" : c.match_type === "new" ? "✦ new" : "# id"}
                                </span>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </>
                )}
              </div>
            )}

            {/* CHARTS TAB */}
            {tab === "charts" && (
              loading ? <Spinner text="Loading data…" /> :
              <ChartsTab items={items} history={history} />
            )}

            {/* ITEMS TAB */}
            {tab === "items" && (
              <div className="fade-up">
                <div style={{ display: "flex", alignItems: "center", gap: 14, marginBottom: 22 }}>
                  <div style={{ fontFamily: "'Playfair Display', serif", fontSize: 22, color: "#f0f6fc", flex: 1 }}>
                    All Items <span style={{ fontSize: 14, color: "#475569", fontFamily: "inherit" }}>({filteredItems.length})</span>
                  </div>
                  <input placeholder="Search items…" value={search} onChange={(e) => setSearch(e.target.value)}
                    style={{ background: "#0d1117", border: "1px solid #1e2530", borderRadius: 8, padding: "8px 14px", fontSize: 12, color: "#e2e8f0", width: 220, outline: "none", fontFamily: "inherit" }} />
                  <a href={`${API}/download`} style={{ padding: "8px 16px", background: "#064e3b", color: "#34d399", border: "1px solid #065f46", borderRadius: 8, fontSize: 11, textDecoration: "none" }}>↓ Download</a>
                </div>
                {loading ? <Spinner text="Loading items…" /> : filteredItems.length === 0 ? (
                  <EmptyState icon="▤" text="No items yet. Upload an invoice to populate the database." />
                ) : (
                  <div style={{ border: "1px solid #1e2530", borderRadius: 10, overflow: "hidden" }}>
                    <table style={{ width: "100%", borderCollapse: "collapse" }}>
                      <thead>
                        <tr style={{ background: "#111827" }}>
                          {["Item #", "Description", "Current Price", "Prev Price", "Change", "Updated", "Invoice"].map((h) => (
                            <th key={h} style={{ textAlign: "left", padding: "11px 16px", fontSize: 10, letterSpacing: "0.1em", textTransform: "uppercase", color: "#475569", borderBottom: "1px solid #1e2530", fontWeight: 500 }}>{h}</th>
                          ))}
                        </tr>
                      </thead>
                      <tbody>
                        {filteredItems.map((it, i) => {
                          const chg = it["Change %"] ? parseFloat(it["Change %"]) : null;
                          return (
                            <tr key={i} className="row-hover" style={{ borderBottom: "1px solid #111827" }} onClick={() => openItemHistory(it["Item Number"])}>
                              <td style={{ padding: "11px 16px", fontSize: 12, color: "#60a5fa" }}>{it["Item Number"]}</td>
                              <td style={{ padding: "11px 16px", fontSize: 12, color: "#e2e8f0" }}>{it["Description"]}</td>
                              <td style={{ padding: "11px 16px", fontSize: 12, color: chg > 0 ? "#f87171" : chg < 0 ? "#4ade80" : "#94a3b8" }}>{fmt(it["Current Price"])}</td>
                              <td style={{ padding: "11px 16px", fontSize: 12, color: "#334155", textDecoration: "line-through" }}>{it["Previous Price"] ? fmt(it["Previous Price"]) : "—"}</td>
                              <td style={{ padding: "11px 16px", fontSize: 12 }}>
                                {it["Change %"] ? <span style={{ color: chg > 0 ? "#f87171" : chg < 0 ? "#4ade80" : "#64748b" }}>{chg > 0 ? "+" : ""}{it["Change %"]}</span> : "—"}
                              </td>
                              <td style={{ padding: "11px 16px", fontSize: 11, color: "#475569" }}>{it["Last Updated"] || "—"}</td>
                              <td style={{ padding: "11px 16px" }}>
                                <span style={{ fontSize: 10, padding: "2px 8px", borderRadius: 4, background: "#111827", color: "#475569", border: "1px solid #1e2530" }}>
                                  {String(it["Invoice Source"] || "").replace(/\.pdf$/i, "") || "—"}
                                </span>
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                )}
                {selectedItem && (
                  <div style={{ marginTop: 24, background: "#0d1117", border: "1px solid #3b82f6", borderRadius: 10, overflow: "hidden" }}>
                    <div style={{ background: "#111827", padding: "12px 18px", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                      <div style={{ fontSize: 12, color: "#60a5fa" }}>Price history for <strong>{selectedItem}</strong></div>
                      <div style={{ fontSize: 11, color: "#475569", cursor: "pointer" }} onClick={() => setSelectedItem(null)}>✕ close</div>
                    </div>
                    {itemHistory.length === 0 ? (
                      <div style={{ padding: 24, fontSize: 12, color: "#475569" }}>No history found.</div>
                    ) : (
                      <table style={{ width: "100%", borderCollapse: "collapse" }}>
                        <thead>
                          <tr style={{ background: "#0d1117" }}>
                            {["Date", "Old Price", "New Price", "Change %", "Status", "Invoice"].map((h) => (
                              <th key={h} style={{ textAlign: "left", padding: "9px 16px", fontSize: 10, color: "#475569", letterSpacing: "0.08em", textTransform: "uppercase", borderBottom: "1px solid #1e2530" }}>{h}</th>
                            ))}
                          </tr>
                        </thead>
                        <tbody>
                          {itemHistory.map((h, i) => (
                            <tr key={i} style={{ borderBottom: "1px solid #111827" }}>
                              <td style={{ padding: "9px 16px", fontSize: 11, color: "#64748b" }}>{h["Date"]}</td>
                              <td style={{ padding: "9px 16px", fontSize: 12, color: "#475569", textDecoration: "line-through" }}>{fmt(h["Old Price"])}</td>
                              <td style={{ padding: "9px 16px", fontSize: 12, color: "#94a3b8" }}>{fmt(h["New Price"])}</td>
                              <td style={{ padding: "9px 16px", fontSize: 12, color: "#64748b" }}>{h["Change %"]}</td>
                              <td style={{ padding: "9px 16px" }}><StatusBadge status={h["Status"]?.toLowerCase()} /></td>
                              <td style={{ padding: "9px 16px", fontSize: 11, color: "#475569" }}>{String(h["Invoice Source"] || "").replace(/\.pdf$/i, "")}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    )}
                  </div>
                )}
              </div>
            )}

            {/* HISTORY TAB */}
            {tab === "history" && (
              <div className="fade-up">
                <div style={{ display: "flex", alignItems: "center", marginBottom: 22 }}>
                  <div style={{ fontFamily: "'Playfair Display', serif", fontSize: 22, color: "#f0f6fc", flex: 1 }}>
                    Price History <span style={{ fontSize: 14, color: "#475569", fontFamily: "inherit" }}>({history.length})</span>
                  </div>
                  <a href={`${API}/download`} style={{ padding: "8px 16px", background: "#064e3b", color: "#34d399", border: "1px solid #065f46", borderRadius: 8, fontSize: 11, textDecoration: "none" }}>↓ Download</a>
                </div>
                {loading ? <Spinner text="Loading history…" /> : history.length === 0 ? (
                  <EmptyState icon="◷" text="No history yet. Price changes will appear here after processing invoices." />
                ) : (
                  <div style={{ border: "1px solid #1e2530", borderRadius: 10, overflow: "hidden" }}>
                    <table style={{ width: "100%", borderCollapse: "collapse" }}>
                      <thead>
                        <tr style={{ background: "#111827" }}>
                          {["Date", "Item #", "Description", "Old Price", "New Price", "Change %", "Status", "Invoice"].map((h) => (
                            <th key={h} style={{ textAlign: "left", padding: "11px 16px", fontSize: 10, letterSpacing: "0.1em", textTransform: "uppercase", color: "#475569", borderBottom: "1px solid #1e2530", fontWeight: 500 }}>{h}</th>
                          ))}
                        </tr>
                      </thead>
                      <tbody>
                        {history.map((h, i) => {
                          const chg = h["Change %"] ? parseFloat(h["Change %"]) : 0;
                          return (
                            <tr key={i} style={{ borderBottom: "1px solid #111827" }}>
                              <td style={{ padding: "11px 16px", fontSize: 11, color: "#64748b" }}>{h["Date"]}</td>
                              <td style={{ padding: "11px 16px", fontSize: 12, color: "#60a5fa" }}>{h["Item Number"]}</td>
                              <td style={{ padding: "11px 16px", fontSize: 12, color: "#e2e8f0", maxWidth: 200 }}>{h["Description"]}</td>
                              <td style={{ padding: "11px 16px", fontSize: 12, color: "#475569", textDecoration: "line-through" }}>{h["Old Price"] !== "—" ? fmt(h["Old Price"]) : "—"}</td>
                              <td style={{ padding: "11px 16px", fontSize: 12, color: chg > 0 ? "#f87171" : chg < 0 ? "#4ade80" : "#94a3b8" }}>{fmt(h["New Price"])}</td>
                              <td style={{ padding: "11px 16px", fontSize: 12, color: chg > 0 ? "#f87171" : chg < 0 ? "#4ade80" : "#64748b" }}>{h["Change %"]}</td>
                              <td style={{ padding: "11px 16px" }}><StatusBadge status={h["Status"]?.toLowerCase()} /></td>
                              <td style={{ padding: "11px 16px" }}>
                                <span style={{ fontSize: 10, padding: "2px 8px", borderRadius: 4, background: "#111827", color: "#475569", border: "1px solid #1e2530" }}>
                                  {String(h["Invoice Source"] || "").replace(/\.pdf$/i, "") || "—"}
                                </span>
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            )}

          </div>
        </div>
      </div>
    </>
  );
}