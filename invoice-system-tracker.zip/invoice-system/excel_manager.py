"""
Step 3 — Excel Manager
========================
Handles all read/write operations for the invoice tracker Excel database.

Two sheets:
  - "Items"         : Master item list (one row per unique item_number)
  - "Price History" : Full audit log of every price change

Usage:
    from excel_manager import ExcelManager

    mgr = ExcelManager("invoice_tracker.xlsx")
    changes = mgr.process_items(extracted_items, invoice_name="INV-001.pdf")
    mgr.save()
    print(changes)
"""

import os
from datetime import date
from pathlib import Path
from typing import Optional
import openpyxl
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

# ── Sheet names ───────────────────────────────────────────────────────────────
ITEMS_SHEET   = "Items"
HISTORY_SHEET = "Price History"

# ── Column definitions ────────────────────────────────────────────────────────
ITEMS_COLS = [
    "Item Number",
    "Description",
    "Current Price",
    "Previous Price",
    "Change %",
    "Change Direction",
    "Last Updated",
    "Invoice Source",
]

HISTORY_COLS = [
    "Date",
    "Invoice Source",
    "Item Number",
    "Description",
    "Old Price",
    "New Price",
    "Change Amount",
    "Change %",
    "Status",
]

# ── Styling helpers ───────────────────────────────────────────────────────────
HEADER_FILL   = PatternFill("solid", fgColor="1F2D3D")
HEADER_FONT   = Font(bold=True, color="FFFFFF", name="Calibri", size=11)
NEW_FILL      = PatternFill("solid", fgColor="D0F0FD")   # light blue
UP_FILL       = PatternFill("solid", fgColor="FDE8E8")   # light red
DOWN_FILL     = PatternFill("solid", fgColor="D4EDDA")   # light green
SAME_FILL     = PatternFill("solid", fgColor="F8F9FA")   # light grey
CENTER        = Alignment(horizontal="center", vertical="center")
LEFT          = Alignment(horizontal="left",   vertical="center")

def _normalize_desc(desc: str) -> str:
    """Normalize description for fuzzy matching — lowercase, strip extra spaces."""
    import re
    return re.sub(r'\s+', ' ', desc.lower().strip())


def _thin_border():
    s = Side(style="thin", color="DDDDDD")
    return Border(left=s, right=s, top=s, bottom=s)


class ExcelManager:
    """Manages the invoice tracker Excel workbook."""

    def __init__(self, filepath: str = "invoice_tracker.xlsx"):
        self.filepath = Path(filepath)
        self.wb: Workbook = self._load_or_create()

    # ── Load / Create ─────────────────────────────────────────────────────────
    def _load_or_create(self) -> Workbook:
        if self.filepath.exists():
            wb = openpyxl.load_workbook(self.filepath)
            # Ensure both sheets exist
            if ITEMS_SHEET not in wb.sheetnames:
                self._create_items_sheet(wb)
            if HISTORY_SHEET not in wb.sheetnames:
                self._create_history_sheet(wb)
            return wb
        else:
            wb = Workbook()
            wb.remove(wb.active)           # remove default sheet
            self._create_items_sheet(wb)
            self._create_history_sheet(wb)
            return wb

    def _create_items_sheet(self, wb: Workbook):
        ws = wb.create_sheet(ITEMS_SHEET)
        self._write_header(ws, ITEMS_COLS)
        self._style_items_sheet(ws)

    def _create_history_sheet(self, wb: Workbook):
        ws = wb.create_sheet(HISTORY_SHEET)
        self._write_header(ws, HISTORY_COLS)
        self._style_history_sheet(ws)

    # ── Core: process extracted items ─────────────────────────────────────────
    def process_items(self, extracted: list[dict], invoice_name: str) -> list[dict]:
        """
        Merge extracted items into the Items sheet.
        Append change records to Price History sheet.

        Args:
            extracted    : [{item_number, description, unit_price}, ...]
            invoice_name : filename of the source invoice PDF

        Returns:
            changes: list of dicts describing what happened to each item
                     each dict has keys: item_number, description,
                     old_price, new_price, change_pct, status
        """
        ws_items   = self.wb[ITEMS_SHEET]
        ws_history = self.wb[HISTORY_SHEET]
        today      = date.today().isoformat()
        changes    = []

        # Build lookups: item_number → row index AND description → row index
        existing        = self._build_lookup(ws_items)
        desc_lookup     = self._build_desc_lookup(ws_items)

        for item in extracted:
            item_no   = str(item["item_number"]).strip()
            desc      = str(item["description"]).strip()
            new_price = float(item["unit_price"])

            # ── Smart match: item number first, then description fallback ─────
            match_row    = None
            match_type   = None
            desc_key     = _normalize_desc(desc)

            if item_no in existing:
                match_row  = existing[item_no]
                match_type = "item_number"
            elif desc_key in desc_lookup:
                match_row  = desc_lookup[desc_key]
                match_type = "description"
                # Update item_no to use the canonical one from DB
                item_no = str(ws_items.cell(row=match_row, column=1).value).strip()

            if match_row is None:
                # ── NEW item ──────────────────────────────────────────────────
                row_data = [
                    item_no, desc,
                    new_price, "",
                    "", "NEW",
                    today, invoice_name,
                ]
                ws_items.append(row_data)
                row_idx = ws_items.max_row
                self._style_data_row(ws_items, row_idx, "new")
                existing[item_no]    = row_idx
                desc_lookup[desc_key] = row_idx

                changes.append({
                    "item_number": item_no,
                    "description": desc,
                    "old_price":   None,
                    "new_price":   new_price,
                    "change_amt":  None,
                    "change_pct":  None,
                    "status":      "new",
                    "match_type":  "new",
                })

                # Log to history
                self._append_history(ws_history, today, invoice_name,
                                     item_no, desc, None, new_price, "new")

            else:
                # ── EXISTING item (matched by item_number or description) ──────
                row_idx   = match_row
                old_price = ws_items.cell(row=row_idx, column=3).value or 0.0
                old_price = float(old_price)

                change_amt = round(new_price - old_price, 2)
                change_pct = round(((new_price - old_price) / old_price) * 100, 2) \
                             if old_price != 0 else None

                if change_amt > 0:
                    status = "increased"
                elif change_amt < 0:
                    status = "decreased"
                else:
                    status = "unchanged"

                direction = "↑" if status == "increased" else "↓" if status == "decreased" else "→"
                pct_str   = f"{change_pct:+.2f}%" if change_pct is not None else "0.00%"

                # Update row
                ws_items.cell(row=row_idx, column=2).value = desc
                ws_items.cell(row=row_idx, column=3).value = new_price
                ws_items.cell(row=row_idx, column=4).value = old_price
                ws_items.cell(row=row_idx, column=5).value = pct_str
                ws_items.cell(row=row_idx, column=6).value = direction
                ws_items.cell(row=row_idx, column=7).value = today
                ws_items.cell(row=row_idx, column=8).value = invoice_name
                self._style_data_row(ws_items, row_idx, status)

                changes.append({
                    "item_number": item_no,
                    "description": desc,
                    "old_price":   old_price,
                    "new_price":   new_price,
                    "change_amt":  change_amt,
                    "change_pct":  change_pct,
                    "status":      status,
                    "match_type":  match_type,
                })

                # Log to history
                self._append_history(ws_history, today, invoice_name,
                                     item_no, desc, old_price, new_price, status)

        return changes

    # ── Read helpers ──────────────────────────────────────────────────────────
    def get_all_items(self) -> list[dict]:
        """Return all items from the Items sheet as a list of dicts."""
        ws = self.wb[ITEMS_SHEET]
        rows = list(ws.iter_rows(min_row=2, values_only=True))
        return [dict(zip(ITEMS_COLS, row)) for row in rows if row[0]]

    def get_history(self) -> list[dict]:
        """Return full price history as a list of dicts."""
        ws = self.wb[HISTORY_SHEET]
        rows = list(ws.iter_rows(min_row=2, values_only=True))
        return [dict(zip(HISTORY_COLS, row)) for row in rows if row[0]]

    def get_item_history(self, item_number: str) -> list[dict]:
        """Return price history for a specific item."""
        return [h for h in self.get_history()
                if str(h.get("Item Number", "")).strip().lower() == item_number.strip().lower()]

    # ── Save ──────────────────────────────────────────────────────────────────
    def save(self, filepath: Optional[str] = None):
        """Save workbook to disk."""
        path = Path(filepath) if filepath else self.filepath
        path.parent.mkdir(parents=True, exist_ok=True)
        self.wb.save(path)
        return str(path)

    def to_bytes(self) -> bytes:
        """Return workbook as raw bytes (for FastAPI file response)."""
        import io
        buf = io.BytesIO()
        self.wb.save(buf)
        buf.seek(0)
        return buf.read()

    # ── Internal helpers ──────────────────────────────────────────────────────
    def _build_lookup(self, ws) -> dict:
        """Build {item_number: row_index} from Items sheet."""
        lookup = {}
        for row in ws.iter_rows(min_row=2):
            val = row[0].value
            if val:
                lookup[str(val).strip()] = row[0].row
        return lookup

    def _build_desc_lookup(self, ws) -> dict:
        """Build {normalized_description: row_index} from Items sheet."""
        lookup = {}
        for row in ws.iter_rows(min_row=2):
            val = row[1].value  # Description is column 2
            if val:
                lookup[_normalize_desc(str(val))] = row[0].row
        return lookup

    def _append_history(self, ws, today, invoice_name, item_no,
                        desc, old_price, new_price, status):
        change_amt = round(new_price - (old_price or 0), 2) if old_price is not None else None
        change_pct = (
            f"{round(((new_price - old_price) / old_price) * 100, 2):+.2f}%"
            if old_price and old_price != 0 else "NEW"
        )
        row = [today, invoice_name, item_no, desc,
               old_price if old_price is not None else "—",
               new_price, change_amt, change_pct, status.upper()]
        ws.append(row)
        self._style_data_row(ws, ws.max_row, status)

    def _write_header(self, ws, cols: list):
        ws.append(cols)
        for col_idx, _ in enumerate(cols, start=1):
            cell = ws.cell(row=1, column=col_idx)
            cell.font      = HEADER_FONT
            cell.fill      = HEADER_FILL
            cell.alignment = CENTER
            cell.border    = _thin_border()
        ws.row_dimensions[1].height = 22

    def _style_data_row(self, ws, row_idx: int, status: str):
        fill = {
            "new":       NEW_FILL,
            "increased": UP_FILL,
            "decreased": DOWN_FILL,
        }.get(status, SAME_FILL)

        for cell in ws[row_idx]:
            cell.fill      = fill
            cell.border    = _thin_border()
            cell.alignment = LEFT
            cell.font      = Font(name="Calibri", size=10)

    def _style_items_sheet(self, ws):
        col_widths = [15, 35, 15, 15, 12, 12, 14, 25]
        for i, w in enumerate(col_widths, start=1):
            ws.column_dimensions[get_column_letter(i)].width = w
        ws.freeze_panes = "A2"

    def _style_history_sheet(self, ws):
        col_widths = [12, 25, 15, 35, 12, 12, 14, 12, 12]
        for i, w in enumerate(col_widths, start=1):
            ws.column_dimensions[get_column_letter(i)].width = w
        ws.freeze_panes = "A2"


# ── Quick test ────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    import tempfile, os

    test_file = "test_invoice_tracker.xlsx"

    # Simulate Invoice #1
    mgr = ExcelManager(test_file)
    changes1 = mgr.process_items([
        {"item_number": "A-101", "description": "Industrial Widget",    "unit_price": 25.00},
        {"item_number": "B-202", "description": "Copper Fitting 3in",   "unit_price": 12.50},
        {"item_number": "C-303", "description": "Safety Valve Pro",     "unit_price": 89.99},
    ], invoice_name="INV-2024-001.pdf")
    mgr.save()
    print(f"Invoice #1 → {len(changes1)} changes")
    for c in changes1:
        print(f"  [{c['status'].upper():>10}]  {c['item_number']}  ${c['new_price']:.2f}")

    # Simulate Invoice #2 — price changes + new item
    mgr2 = ExcelManager(test_file)
    changes2 = mgr2.process_items([
        {"item_number": "A-101", "description": "Industrial Widget",    "unit_price": 27.50},  # ↑ price
        {"item_number": "B-202", "description": "Copper Fitting 3in",   "unit_price": 11.00},  # ↓ price
        {"item_number": "C-303", "description": "Safety Valve Pro",     "unit_price": 89.99},  # same
        {"item_number": "D-404", "description": "Steel Bolt Pack",      "unit_price": 4.75},   # new
    ], invoice_name="INV-2024-002.pdf")
    mgr2.save()
    print(f"\nInvoice #2 → {len(changes2)} changes")
    for c in changes2:
        pct = f"{c['change_pct']:+.2f}%" if c['change_pct'] is not None else "NEW"
        print(f"  [{c['status'].upper():>10}]  {c['item_number']}  "
              f"${c.get('old_price') or 0:.2f} → ${c['new_price']:.2f}  ({pct})")

    print(f"\n✓ Saved to {test_file}")
    print(f"  Items in DB  : {len(mgr2.get_all_items())}")
    print(f"  History rows : {len(mgr2.get_history())}")

    os.remove(test_file)
    print("\n✓ Test file cleaned up")