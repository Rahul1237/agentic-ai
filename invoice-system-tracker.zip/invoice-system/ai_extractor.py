"""
Step 2 — AI Extraction Module (OpenAI GPT-4o)
===============================================
Sends raw PDF text to GPT-4o and returns structured invoice line items.

Usage:
    from ai_extractor import extract_invoice_items
    items = extract_invoice_items(pdf_text)
    # [{"item_number": "A-101", "description": "Widget", "unit_price": 25.00}, ...]
"""

import os
import json
import re
from openai import OpenAI
from typing import Optional

# ── Config ────────────────────────────────────────────────────────────────────
MODEL      = "gpt-4o"
MAX_TOKENS = 2048

SYSTEM_PROMPT = """You are an expert invoice parser that handles all types of invoices including
Coca-Cola, Core-Mark, tobacco distributors, food service, and general wholesale invoices.

Your job is to extract every product line item and return ONLY a valid JSON array.

Each object must have exactly these keys:
  - item_number  (string)  — product code, SKU, item ID, or UPC. If none found use "ITEM-001", "ITEM-002" etc.
  - description  (string)  — full product name/description, cleaned and corrected
  - unit_price   (number)  — the selling price or net price per unit as a plain float

Important rules:
- Return ONLY the JSON array. No markdown, no backticks, no explanation whatsoever.
- Look for columns named: SELLING PRICE, NET, UNIT PRICE, PRICE, RATE, EXTENDED, AMOUNT
- Prefer SELLING PRICE or NET column over SUGGESTED RETAIL
- Strip all currency symbols ($, €, £) from prices
- Ignore header rows, subtotals, totals, discounts, tax rows, and commodity total rows
- Ignore rows with "LESS SPECIAL DISCOUNT", "COMMODITY TOTAL", "DEPOSIT" etc.
- If OCR text is messy or columns are misaligned, do your best to match item numbers to descriptions to prices
- If a line item has no price, set unit_price to 0.0
- If there are truly no line items, return []

OCR correction rules (fix these common scan errors in descriptions):
- Cigarette sizes: "200 MM" should always be "100 MM" — 200MM cigarettes do not exist
- "PILTER" should be "FILTER"
- "TURQSE" should be "TURQUOISE"  
- Fix obvious letter/number OCR swaps: "0" vs "O", "1" vs "l", "5" vs "S"
- Clean up garbled text but preserve the core product name
"""

USER_PROMPT_TEMPLATE = """Extract all product line items from this invoice text.

For invoices like Core-Mark, each line follows this pattern:
  ITEM_NUMBER | UPC_CODE  [symbols] DESCRIPTION  PACKING  SUGG_RETAIL  GP%  RETAIL_EXT  SELLING_PRICE  EXTENSION

Rules:
- item_number = the FIRST number on the line (before the | separator), e.g. "074096", "369611"
- DO NOT use the UPC (the second number after |) as item_number
- description = the product name text in the middle of the line
- unit_price = the SELLING PRICE column (second-to-last number on the line)
- Ignore lines with "COMMODITY TOTAL", "LESS SPECIAL DISCOUNT", "CLASS 1", "CLASS 2", "TOBACCO"

Example:
  074096 | 07310000107  COPENHAGEN FC NATURAL  S/TIN  8.59  28.0  42.95  30.92  30.92
  → item_number: "074096"   ← FIRST number only
  → description: "COPENHAGEN FC NATURAL"
  → unit_price: 30.92       ← second-to-last number

Invoice text:
{text}
"""


# ── Main function ─────────────────────────────────────────────────────────────
def extract_invoice_items(pdf_text: str, api_key: Optional[str] = None) -> list[dict]:
    """
    Send PDF text to GPT-4o and get back structured line items.

    Args:
        pdf_text : Raw text extracted from the invoice PDF
        api_key  : OpenAI API key. Falls back to OPENAI_API_KEY env var.

    Returns:
        List of dicts: [{item_number, description, unit_price}, ...]
    """
    if not pdf_text or not pdf_text.strip():
        raise ValueError("pdf_text is empty — nothing to extract from.")

    client = OpenAI(api_key=api_key or os.environ.get("OPENAI_API_KEY"))

    try:
        response = client.chat.completions.create(
            model=MODEL,
            max_tokens=MAX_TOKENS,
            temperature=0,
            messages=[
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user",   "content": USER_PROMPT_TEMPLATE.format(text=pdf_text[:12000])}
            ]
        )
    except Exception as e:
        raise RuntimeError(f"OpenAI API call failed: {e}") from e

    raw = response.choices[0].message.content.strip()

    items = _parse_json_response(raw)
    items = _validate_and_clean(items)
    return items


# ── Helpers ───────────────────────────────────────────────────────────────────
def _parse_json_response(raw: str) -> list:
    clean = re.sub(r"```(?:json)?", "", raw).strip().strip("`").strip()
    try:
        parsed = json.loads(clean)
    except json.JSONDecodeError as e:
        raise ValueError(
            f"GPT-4o returned invalid JSON: {e}\nRaw response:\n{raw[:300]}"
        ) from e
    if not isinstance(parsed, list):
        raise ValueError(f"Expected a JSON array, got: {type(parsed)}")
    return parsed


def _validate_and_clean(items: list) -> list[dict]:
    cleaned = []
    for i, item in enumerate(items, start=1):
        if not isinstance(item, dict):
            continue

        item_number = str(item.get("item_number") or f"ITEM-{i:03d}").strip()
        description = str(item.get("description") or "Unknown").strip()

        raw_price = item.get("unit_price", 0)
        try:
            unit_price = float(
                str(raw_price)
                .replace(",", "").replace("$", "")
                .replace("€", "").replace("£", "").strip()
            )
        except (ValueError, TypeError):
            unit_price = 0.0

        cleaned.append({
            "item_number": item_number,
            "description": description,
            "unit_price":  round(unit_price, 2),
        })

    return cleaned