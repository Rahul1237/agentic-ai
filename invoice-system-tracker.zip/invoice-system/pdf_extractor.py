"""
Step 1 — PDF Extraction Module (with OCR)
==========================================
Extracts raw text from invoice PDFs.
Supports both text-based and scanned (image) PDFs.

Extraction order:
  1. pdfplumber  — best for text-based PDFs with tables
  2. pypdf       — fallback for simple text PDFs
  3. OCR         — fallback for scanned/image PDFs (uses pdf2image + pytesseract)

Install requirements:
    pip install pdfplumber pypdf pdf2image pillow pytesseract
    Windows: install Tesseract from https://github.com/UB-Mannheim/tesseract/wiki
    Windows: install Poppler from https://github.com/oschwartz10612/poppler-windows/releases
"""

import io
import os
import platform
from pathlib import Path
from typing import Union

import pdfplumber
from pypdf import PdfReader


def extract_pdf_content(source: Union[str, bytes, io.BytesIO]) -> dict:
    """
    Extract text from a PDF file (text-based or scanned).

    Args:
        source: File path (str), raw bytes, or BytesIO object

    Returns:
        {
            "text"  : str,        # full plain text, all pages joined
            "tables": list[list], # list of tables (text PDFs only)
            "pages" : int,        # total page count
            "source": str,        # original filename or "bytes"
            "method": str,        # extraction method used
        }
    """
    # ── Normalise input → bytes ───────────────────────────────────────────────
    if isinstance(source, (str, Path)):
        source_name = Path(source).name
        with open(source, "rb") as f:
            raw_bytes = f.read()
    elif isinstance(source, bytes):
        source_name = "bytes"
        raw_bytes = source
    elif isinstance(source, io.BytesIO):
        source_name = "bytesio"
        source.seek(0)
        raw_bytes = source.read()
    else:
        raise TypeError(f"Unsupported source type: {type(source)}")

    data = io.BytesIO(raw_bytes)

    # ── Method 1: pdfplumber ──────────────────────────────────────────────────
    text, tables, page_count = _try_pdfplumber(data)
    if text.strip():
        return {"text": text, "tables": tables, "pages": page_count,
                "source": source_name, "method": "pdfplumber"}

    # ── Method 2: pypdf ───────────────────────────────────────────────────────
    data.seek(0)
    text, page_count = _try_pypdf(data)
    if text.strip():
        return {"text": text, "tables": [], "pages": page_count,
                "source": source_name, "method": "pypdf"}

    # ── Method 3: OCR at 300 DPI with grayscale ───────────────────────────────
    text, page_count = _try_ocr(raw_bytes)
    if text.strip():
        return {"text": text, "tables": [], "pages": page_count,
                "source": source_name, "method": "ocr"}

    return {"text": "", "tables": [], "pages": page_count,
            "source": source_name, "method": "none"}


# ── Extraction methods ────────────────────────────────────────────────────────

def _try_pdfplumber(data: io.BytesIO):
    text_pages = []
    all_tables = []
    page_count = 0
    try:
        data.seek(0)
        with pdfplumber.open(data) as pdf:
            page_count = len(pdf.pages)
            for page in pdf.pages:
                t = page.extract_text(x_tolerance=2, y_tolerance=2)
                if t:
                    text_pages.append(t.strip())
                for table in page.extract_tables():
                    cleaned = _clean_table(table)
                    if cleaned:
                        all_tables.append(cleaned)
    except Exception as e:
        print(f"[pdf_extractor] pdfplumber failed: {e}")
    return "\n\n".join(text_pages), all_tables, page_count


def _try_pypdf(data: io.BytesIO):
    text_pages = []
    page_count = 0
    try:
        data.seek(0)
        reader = PdfReader(data)
        page_count = len(reader.pages)
        for page in reader.pages:
            t = page.extract_text()
            if t:
                text_pages.append(t.strip())
    except Exception as e:
        print(f"[pdf_extractor] pypdf failed: {e}")
    return "\n\n".join(text_pages), page_count


def _try_ocr(raw_bytes: bytes):
    """OCR at 300 DPI with grayscale for best accuracy on scanned invoices."""
    text_pages = []
    page_count = 0
    try:
        from pdf2image import convert_from_bytes
        import pytesseract

        # ── Windows: auto-detect Tesseract path ──────────────────────────────
        if platform.system() == "Windows":
            possible_paths = [
                r"C:\Program Files\Tesseract-OCR\tesseract.exe",
                r"C:\Program Files (x86)\Tesseract-OCR\tesseract.exe",
                os.path.join(os.environ.get("LOCALAPPDATA", ""), "Tesseract-OCR", "tesseract.exe"),
            ]
            for p in possible_paths:
                if os.path.exists(p):
                    pytesseract.pytesseract.tesseract_cmd = p
                    break

        # ── Convert PDF pages to images at 300 DPI ────────────────────────────
        images = convert_from_bytes(raw_bytes, dpi=300)
        page_count = len(images)

        for img in images:
            # Convert to grayscale for better OCR accuracy
            img_gray = img.convert('L')
            # psm 6 = assume uniform block of text (best for invoices)
            t = pytesseract.image_to_string(img_gray, config='--psm 6')
            if t:
                text_pages.append(t.strip())

    except ImportError:
        print("[pdf_extractor] OCR libs not installed: pip install pdf2image pytesseract pillow")
    except Exception as e:
        print(f"[pdf_extractor] OCR failed: {e}")

    return "\n\n".join(text_pages), page_count


def _clean_table(raw_table: list) -> list:
    cleaned = []
    for row in raw_table:
        clean_row = [str(cell).strip() if cell is not None else "" for cell in row]
        if any(cell for cell in clean_row):
            cleaned.append(clean_row)
    return cleaned