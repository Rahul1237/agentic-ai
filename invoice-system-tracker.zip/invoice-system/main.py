"""
Step 4 — FastAPI Backend (main.py)
====================================
REST API that ties together pdf_extractor, ai_extractor, and excel_manager.

Endpoints:
  POST /upload-invoice        → Upload PDF, extract items, update Excel
  GET  /items                 → Get all tracked items
  GET  /history               → Get full price history
  GET  /history/{item_number} → Get price history for one item
  GET  /download              → Download the Excel tracker file
  GET  /health                → Health check

Run:
    uvicorn main:app --reload --port 8000

Env vars (.env file):
    OPENAI_API_KEY=sk-...
    EXCEL_PATH=invoice_tracker.xlsx
"""

import os
import io
from pathlib import Path
from datetime import datetime

from fastapi import FastAPI, File, UploadFile, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse, JSONResponse
from dotenv import load_dotenv

from pdf_extractor import extract_pdf_content
from ai_extractor import extract_invoice_items
from excel_manager import ExcelManager

# ── Load env ──────────────────────────────────────────────────────────────────
load_dotenv()

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
EXCEL_PATH     = os.getenv("EXCEL_PATH", "invoice_tracker.xlsx")

# ── App setup ─────────────────────────────────────────────────────────────────
app = FastAPI(
    title="Invoice Tracker API",
    description="Upload invoice PDFs → extract items with GPT-4o → track price changes in Excel",
    version="1.0.0",
)

# Allow React frontend (localhost:3000) to call the API
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000", "http://127.0.0.1:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ── Helper ────────────────────────────────────────────────────────────────────
def get_excel_manager() -> ExcelManager:
    return ExcelManager(EXCEL_PATH)


# ── Routes ────────────────────────────────────────────────────────────────────

@app.get("/health")
def health_check():
    """Check API is running and Excel file status."""
    excel_exists = Path(EXCEL_PATH).exists()
    mgr = get_excel_manager()
    return {
        "status":       "ok",
        "excel_file":   EXCEL_PATH,
        "excel_exists": excel_exists,
        "total_items":  len(mgr.get_all_items()),
        "total_history": len(mgr.get_history()),
        "timestamp":    datetime.now().isoformat(),
    }


@app.post("/upload-invoice")
async def upload_invoice(file: UploadFile = File(...)):
    """
    Upload a PDF invoice.
    - Extracts text with pdfplumber
    - Sends to GPT-4o for structured extraction
    - Merges results into Excel tracker
    - Returns summary of changes
    """
    # ── Validate file type ────────────────────────────────────────────────────
    if not file.filename.lower().endswith(".pdf"):
        raise HTTPException(status_code=400, detail="Only PDF files are accepted.")

    # ── Read uploaded bytes ───────────────────────────────────────────────────
    try:
        pdf_bytes = await file.read()
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to read uploaded file: {e}")

    # ── Step 1: Extract text from PDF ────────────────────────────────────────
    try:
        pdf_result = extract_pdf_content(pdf_bytes)
    except Exception as e:
        raise HTTPException(status_code=422, detail=f"PDF extraction failed: {e}")

    if not pdf_result["text"].strip():
        raise HTTPException(status_code=422, detail="No readable text found in the PDF.")

    # ── Step 2: AI extraction via GPT-4o ─────────────────────────────────────
    try:
        items = extract_invoice_items(pdf_result["text"], api_key=OPENAI_API_KEY)
    except RuntimeError as e:
        raise HTTPException(status_code=502, detail=f"GPT-4o extraction failed: {e}")
    except ValueError as e:
        raise HTTPException(status_code=422, detail=f"Could not parse AI response: {e}")

    if not items:
        raise HTTPException(status_code=422, detail="No line items found in the invoice.")

    # ── Step 3: Merge into Excel ──────────────────────────────────────────────
    try:
        mgr     = get_excel_manager()
        changes = mgr.process_items(items, invoice_name=file.filename)
        mgr.save()
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Excel update failed: {e}")

    # ── Build response summary ────────────────────────────────────────────────
    new_count       = sum(1 for c in changes if c["status"] == "new")
    increased_count = sum(1 for c in changes if c["status"] == "increased")
    decreased_count = sum(1 for c in changes if c["status"] == "decreased")
    unchanged_count = sum(1 for c in changes if c["status"] == "unchanged")

    return {
        "success":       True,
        "invoice":       file.filename,
        "pages":         pdf_result["pages"],
        "total_items":   len(items),
        "summary": {
            "new":       new_count,
            "increased": increased_count,
            "decreased": decreased_count,
            "unchanged": unchanged_count,
        },
        "changes": [
            {
                "item_number": c["item_number"],
                "description": c["description"],
                "old_price":   c["old_price"],
                "new_price":   c["new_price"],
                "change_amt":  c["change_amt"],
                "change_pct":  c["change_pct"],
                "status":      c["status"],
                "match_type":  c.get("match_type", "item_number"),
            }
            for c in changes
        ],
    }


@app.get("/items")
def get_all_items():
    """Return all tracked items from the Excel database."""
    try:
        mgr   = get_excel_manager()
        items = mgr.get_all_items()
        return {
            "total":  len(items),
            "items":  items,
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/history")
def get_full_history():
    """Return full price change history across all invoices."""
    try:
        mgr     = get_excel_manager()
        history = mgr.get_history()
        return {
            "total":   len(history),
            "history": list(reversed(history)),   # most recent first
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/history/{item_number}")
def get_item_history(item_number: str):
    """Return price history for a specific item number."""
    try:
        mgr     = get_excel_manager()
        history = mgr.get_item_history(item_number)
        if not history:
            raise HTTPException(
                status_code=404,
                detail=f"No history found for item '{item_number}'"
            )
        return {
            "item_number": item_number,
            "total":       len(history),
            "history":     list(reversed(history)),
        }
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/download")
def download_excel():
    """Download the current Excel tracker file."""
    try:
        mgr        = get_excel_manager()
        file_bytes = mgr.to_bytes()
        filename   = Path(EXCEL_PATH).name

        return StreamingResponse(
            io.BytesIO(file_bytes),
            media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            headers={"Content-Disposition": f"attachment; filename={filename}"},
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))