import sys
import os
import argparse

# Add current directory to path for config import
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# Add Agent-S to path
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "Agent-S"))

from config import DEFAULT_LLM_CONFIG, DEFAULT_GROUNDING_CONFIG, DEFAULT_ANDROID_CONFIG
from mobile_qa_agent.main import MobileQAAgent

def main():
    """Main entry point"""
    parser = argparse.ArgumentParser(description="Mobile QA Agent - Multi-Agent Testing System")
    parser.add_argument(
        "--device-id",
        type=str,
        default=None,
        help="Android device ID (optional, for multiple devices)"
    )
    parser.add_argument(
        "--max-steps",
        type=int,
        default=20,
        help="Maximum number of steps per test case"
    )
    parser.add_argument(
        "--test-case",
        type=str,
        default=None,
        help="Run a single test case (description)"
    )
    
    args = parser.parse_args()
    
    # Update Android config with device ID if provided
    android_config = DEFAULT_ANDROID_CONFIG
    if args.device_id:
        android_config.device_id = args.device_id
    
    # Initialize system
    agent_system = MobileQAAgent(
        llm_config=DEFAULT_LLM_CONFIG,
        grounding_config=DEFAULT_GROUNDING_CONFIG,
        android_config=android_config,
        max_steps=args.max_steps
    )
    
    # Run test case or suite
    if args.test_case:
        # Single test case
        result = agent_system.run_test_case(args.test_case)
        print("\n" + "="*60)
        print("TEST RESULT")
        print("="*60)
        print(f"Status: {result['status']}")
        print(f"Result: {result['result']}")
        print(f"Reason: {result['reason']}")
        print("="*60)
    else:
        # Run test suite
        from test_cases import TEST_CASES
        results = agent_system.run_test_suite(TEST_CASES)
        
        # Print summary
        print("\n" + "="*60)
        print("TEST SUITE SUMMARY")
        print("="*60)
        for i, result in enumerate(results, 1):
            test_name = result.get("test_case_info", {}).get("name", f"Test {i}")
            expected = result.get("test_case_info", {}).get("expected_result", "UNKNOWN")
            actual = result.get("result", "UNKNOWN")
            match = "✓" if expected == actual else "✗"
            print(f"{match} {test_name}: Expected {expected}, Got {actual}")
            if result.get("reason"):
                print(f"  Reason: {result['reason'][:100]}")
        print("="*60)

if __name__ == "__main__":
    main()
