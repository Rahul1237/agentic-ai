"""
Executor Agent - Executes planned actions using ADB commands
"""

import logging
import time
import re
from typing import Dict, Tuple
from gui_agents.s3.core.mllm import LMMAgent
from gui_agents.s3.utils.common_utils import call_llm_safe, parse_code_from_string
from .grounding import AndroidACI
from .memory import PROCEDURAL_MEMORY
from config import DEFAULT_PROMPT_CONFIG

logger = logging.getLogger("mobile_qa_agent")


class ExecutorAgent:
    """Executor agent that executes planned actions using the grounding agent"""
    
    def __init__(self, engine_params: Dict, grounding_agent: AndroidACI, prompt_config=None):
        """
        Initialize Executor agent
        
        Args:
            engine_params: LLM engine configuration parameters
            grounding_agent: AndroidACI instance for grounding actions to ADB commands
            prompt_config: Optional prompt configuration (uses DEFAULT_PROMPT_CONFIG if not provided)
        """
        self.engine_params = engine_params
        self.grounding_agent = grounding_agent
        self.prompt_config = prompt_config or DEFAULT_PROMPT_CONFIG
        self.agent = None
        self._initialize_agent()
    
    def _initialize_agent(self, test_case: str = ""):
        """Initialize or reinitialize the executor agent with current test case"""
        from .grounding import AndroidACI
        executor_prompt = PROCEDURAL_MEMORY.construct_executor_prompt(test_case, AndroidACI, self.prompt_config)
        self.agent = LMMAgent(
            engine_params=self.engine_params,
            system_prompt=executor_prompt
        )
    
    def reset(self, test_case: str = ""):
        """Reset executor state"""
        self._initialize_agent(test_case)
        self.agent.reset()
        executor_prompt = PROCEDURAL_MEMORY.construct_executor_prompt(test_case, AndroidACI, self.prompt_config)
        self.agent.add_system_prompt(executor_prompt)
    
    def execute_action(
        self,
        planned_action: str,
        screenshot: bytes,
        test_case: str = ""
    ) -> Tuple[Dict, str]:
        """
        Execute a planned action
        
        Args:
            planned_action: Description of the action to execute
            screenshot: Current screenshot
            test_case: Test case description for context
            
        Returns:
            Tuple of (execution_result, executed_code)
            execution_result: Dict with status and details
            executed_code: The code that was executed
        """
        self.grounding_agent.assign_screenshot({"screenshot": screenshot})
        prompt = self.prompt_config.executor_action_prompt_template.format(
            planned_action=planned_action
        )
        
        self.agent.add_message(
            text_content=prompt,
            image_content=screenshot,
            role="user"
        )
        
        response = call_llm_safe(self.agent, temperature=0.1)
        logger.info(f"Executor response: {response}")
        code = parse_code_from_string(response)
        
        if not code:
            return {
                "status": "error",
                "error": "No valid code found in response",
                "response": response
            }, ""
        
        # Execute the code
        execution_result = self._execute_code(code)
        
        # Add response to agent history
        self.agent.add_message(response, role="assistant")
        
        return execution_result, code
    
    def _execute_code(self, code: str) -> Dict:
        """
        Execute the code using the grounding agent
        Args:
            code: Python code string to execute
        Returns:
            Execution result dictionary
        """
        try:
            if "agent.done()" in code or code.strip() == "DONE":
                return {
                    "status": "success",
                    "action": "done",
                    "message": "Action completed"
                }
            
            if "agent.fail(" in code or code.strip().startswith("FAIL"):
                reason = "Unknown"
                match = re.search(r'fail\(["\'](.*?)["\']', code)
                if match:
                    reason = match.group(1)
                return {
                    "status": "failure",
                    "action": "fail",
                    "reason": reason
                }
            
            if "agent.wait(" in code or code.strip().startswith("WAIT"):
                seconds = 1.0
                match = re.search(r'wait\(([\d.]+)\)', code)
                if match:
                    seconds = float(match.group(1))
                time.sleep(seconds)
                return {
                    "status": "success",
                    "action": "wait",
                    "seconds": seconds
                }

            local_scope = {"agent": self.grounding_agent}
            exec(code, {"__builtins__": __builtins__}, local_scope)
            result = {
                "status": "success",
                "action": "executed",
                "code": code
            }
            
            return result
            
        except Exception as e:
            logger.error(f"Error executing code: {e}")
            return {
                "status": "error",
                "error": str(e),
                "code": code
            }
    
    def get_action_summary(self, execution_result: Dict, code: str) -> str:
        """Generate a summary of the executed action"""
        if execution_result.get("status") == "success":
            if execution_result.get("action") == "done":
                return "Action completed successfully"
            elif execution_result.get("action") == "wait":
                return f"Waited {execution_result.get('seconds', 0)} seconds"
            else:
                return f"Executed: {code[:100]}"
        elif execution_result.get("status") == "failure":
            return f"Action failed: {execution_result.get('reason', 'Unknown reason')}"
        else:
            return f"Error: {execution_result.get('error', 'Unknown error')}"