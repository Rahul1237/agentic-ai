"""
Main orchestration script for Mobile QA Agent system
Supervisor-Planner-Executor architecture for mobile app testing
"""

import logging
import time
from typing import Dict, List

import sys
import os

current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(os.path.dirname(current_dir))
sys.path.insert(0, parent_dir)

from config import DEFAULT_PROMPT_CONFIG
from .grounding import AndroidACI
from .planner import PlannerAgent
from .executor import ExecutorAgent
from .supervisor import SupervisorAgent

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger("mobile_qa_agent")


class MobileQAAgent:
    """Main orchestration class for the multi-agent QA system"""
    
    def __init__(
        self,
        llm_config,
        grounding_config,
        android_config,
        max_steps: int = 20,
        prompt_config=None
    ):
        """
        Initialize the multi-agent system
        
        Args:
            llm_config: LLM configuration for Gemini
            grounding_config: Grounding model configuration for vLLM
            android_config: Android device configuration
            max_steps: Maximum number of steps per test case
            prompt_config: Optional prompt configuration (uses DEFAULT_PROMPT_CONFIG if not provided)
        """
        self.max_steps = max_steps
        self.prompt_config = prompt_config or DEFAULT_PROMPT_CONFIG
        
        self.llm_engine_params = {
            "engine_type": llm_config.provider,  
            "model": llm_config.model,
            "base_url": llm_config.base_url,
            "api_key": llm_config.api_key,
            "temperature": llm_config.temperature
        }
        
        # Initialize grounding engine params
        self.grounding_engine_params = {
            "engine_type": grounding_config.provider,
            "model": grounding_config.model,
            "base_url": grounding_config.base_url,
            "api_key": "dummy-key",  # Dummy key for local vLLM (not validated)
            "grounding_width": grounding_config.grounding_width,
            "grounding_height": grounding_config.grounding_height
        }
        
        # Initialize grounding agent
        self.grounding_agent = AndroidACI(
            device_id=android_config.device_id,
            screen_width=android_config.screen_width,
            screen_height=android_config.screen_height,
            engine_params_for_grounding=self.grounding_engine_params
        )
        
        # Initialize agents with prompt config
        self.planner = PlannerAgent(self.llm_engine_params, self.prompt_config)
        self.executor = ExecutorAgent(self.llm_engine_params, self.grounding_agent, self.prompt_config)
        self.supervisor = SupervisorAgent(self.llm_engine_params, self.prompt_config)
        
        logger.info("Mobile QA Agent system initialized")
    
    def run_test_case(self, test_case: str) -> Dict:
        """
        Run a single test case through the multi-agent system
        
        Args:
            test_case: Test case description
            
        Returns:
            Test result dictionary
        """
        logger.info(f"Starting test case: {test_case}")

        self.planner.reset()
        self.executor.reset(test_case)
        self.supervisor.reset()

        try:
            initial_screenshot = self.grounding_agent.take_screenshot()
            logger.info("Initial screenshot captured")
        except Exception as e:
            logger.error(f"Failed to take initial screenshot: {e}")
            return {
                "status": "ERROR",
                "error": f"Failed to take screenshot: {e}",
                "test_case": test_case
            }
        
        # Step 1: Planner creates a plan
        logger.info("Planner creating plan...")
        plan_steps = self.planner.plan(test_case, initial_screenshot)
        logger.info(f"Plan created with {len(plan_steps)} steps")
        
        # Execution history
        execution_history = []
        current_screenshot = initial_screenshot
        
        # Step 2: Execute each planned step
        for step_index, step in enumerate(plan_steps):
            if step_index >= self.max_steps:
                logger.warning(f"Reached maximum steps ({self.max_steps}), stopping")
                break
            
            planned_action = step.get("description", "")
            expected_outcome = step.get("expected_outcome", "")
            
            logger.info(f"Step {step_index + 1}/{len(plan_steps)}: {planned_action}")
            
            # Take screenshot before action
            before_screenshot = current_screenshot
            try:
                before_screenshot = self.grounding_agent.take_screenshot()
            except Exception as e:
                logger.warning(f"Failed to take before screenshot: {e}")
            
            # Executor executes the action
            execution_result, executed_code = self.executor.execute_action(
                planned_action=planned_action,
                screenshot=before_screenshot,
                test_case=test_case
            )
            
            logger.info(f"Execution result: {execution_result.get('status')}")
            
            # Wait a bit for UI to update
            time.sleep(1.0)
            
            # Take screenshot after action
            try:
                after_screenshot = self.grounding_agent.take_screenshot()
                current_screenshot = after_screenshot
            except Exception as e:
                logger.warning(f"Failed to take after screenshot: {e}")
                after_screenshot = before_screenshot
            
            # Supervisor verifies the step
            verification = self.supervisor.verify_step(
                planned_action=planned_action,
                execution_result=execution_result,
                before_screenshot=before_screenshot,
                after_screenshot=after_screenshot,
                expected_outcome=expected_outcome
            )
            
            logger.info(f"Verification: {verification.get('result')}")
            
            # Record step
            execution_history.append({
                "step_index": step_index,
                "planned_action": planned_action,
                "expected_outcome": expected_outcome,
                "execution_result": execution_result,
                "executed_code": executed_code,
                "verification": verification
            })
            
            # Check if we should stop early (execution failure or task done)
            if execution_result.get("status") == "failure":
                logger.info("Execution failed, stopping")
                break
            
            if execution_result.get("action") == "done":
                logger.info("Agent signaled completion")
                break
        
        # Step 3: Final verification
        logger.info("Supervisor performing final verification...")
        try:
            final_screenshot = self.grounding_agent.take_screenshot()
        except Exception as e:
            logger.warning(f"Failed to take final screenshot: {e}")
            final_screenshot = current_screenshot
        
        final_verification = self.supervisor.verify_final_state(
            test_case=test_case,
            final_screenshot=final_screenshot,
            execution_history=execution_history
        )
        
        final_result = self._determine_final_result(execution_history, final_verification)

        test_result = {
            "test_case": test_case,
            "status": final_result["status"],
            "result": final_result["result"],
            "reason": final_result["reason"],
            "plan": plan_steps,
            "execution_history": execution_history,
            "final_verification": final_verification,
            "summary": self.supervisor.get_test_summary()
        }
        
        logger.info(f"Test case completed: {final_result['result']}")
        return test_result
    
    def _determine_final_result(self, execution_history: List, final_verification: Dict) -> Dict:
        """Determine the final test result based on execution and verification"""
        for step in execution_history:
            verification = step.get("verification", {})
            if verification.get("verification") == "EXECUTION_FAILURE":
                # Critical execution failure - action couldn't be performed at all
                return {
                    "status": "FAIL",
                    "result": "FAIL",
                    "reason": "EXECUTION_FAILURE: " + verification.get("reason", "Step failed to execute")
                }

        final_result = final_verification.get("result", "UNKNOWN")
        if final_result == "PASS":
            return {
                "status": "PASS",
                "result": "PASS",
                "reason": final_verification.get("reason", "Test case completed successfully")
            }
        elif final_result == "FAIL":
            return {
                "status": "FAIL",
                "result": "FAIL",
                "reason": final_verification.get("reason", "Test case failed")
            }
        else:
            # If final verification is unclear, check if we had any assertion failures
            # But only use this as a fallback - prefer the final verification's judgment
            for step in execution_history:
                verification = step.get("verification", {})
                if verification.get("verification") == "ASSERTION_FAILURE":
                    return {
                        "status": "FAIL",
                        "result": "FAIL",
                        "reason": "ASSERTION_FAILURE: " + verification.get("reason", "Assertion failed")
                    }
            
            return {
                "status": "UNKNOWN",
                "result": "UNKNOWN",
                "reason": "Could not determine final result"
            }
    
    def run_test_suite(self, test_cases: List[Dict]) -> List[Dict]:
        """
        Run a suite of test cases
        
        Args:
            test_cases: List of test case dictionaries
            
        Returns:
            List of test results
        """
        results = []
        
        for test_case in test_cases:
            test_description = test_case.get("description", "")
            logger.info(f"\n{'='*60}")
            logger.info(f"Running: {test_case.get('name', 'Unknown')}")
            logger.info(f"{'='*60}")
            
            result = self.run_test_case(test_description)
            result["test_case_info"] = test_case
            results.append(result)
            
            # Brief pause between tests
            time.sleep(2.0)
        
        return results

