"""
System prompts and procedural memory for mobile QA agents
"""

import inspect
from config import DEFAULT_PROMPT_CONFIG


class ProceduralMemory:
    """Procedural memory and system prompts for mobile QA agents"""
    
    def __init__(self, prompt_config=None):
        """Initialize with prompt configuration"""
        self.prompt_config = prompt_config or DEFAULT_PROMPT_CONFIG
    
    @property
    def PLANNER_SYSTEM_PROMPT(self):
        """Get planner system prompt from config"""
        return self.prompt_config.planner_system_prompt
    
    @property
    def EXECUTOR_SYSTEM_PROMPT_TEMPLATE(self):
        """Get executor system prompt template from config"""
        return self.prompt_config.executor_system_prompt_template
    
    @property
    def SUPERVISOR_SYSTEM_PROMPT(self):
        """Get supervisor system prompt from config"""
        return self.prompt_config.supervisor_system_prompt
    
    def construct_executor_prompt(self, test_case: str, agent_class, prompt_config=None):
        """Construct executor prompt with available agent actions"""
        if prompt_config is None:
            prompt_config = self.prompt_config
        
        agent_actions = ""
        for attr_name in dir(agent_class):
            attr = getattr(agent_class, attr_name)
            if callable(attr) and hasattr(attr, "is_agent_action"):
                signature = inspect.signature(attr)
                agent_actions += f"\n    def {attr_name}{signature}:\n        '''{attr.__doc__}'''\n"
        
        return prompt_config.executor_system_prompt_template.format(
            test_case=test_case,
            agent_actions=agent_actions
        )

PROCEDURAL_MEMORY = ProceduralMemory()

