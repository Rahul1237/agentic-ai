"""
Supervisor Agent - Verifies state transitions and determines test outcomes
"""

import logging
import re
from typing import Dict
from gui_agents.s3.core.mllm import LMMAgent
from gui_agents.s3.utils.common_utils import call_llm_safe
from config import DEFAULT_PROMPT_CONFIG

logger = logging.getLogger("mobile_qa_agent")


class SupervisorAgent:
    """Supervisor agent that verifies state transitions and determines test outcomes"""
    
    def __init__(self, engine_params: Dict, prompt_config=None):
        """
        Initialize Supervisor agent
        
        Args:
            engine_params: LLM engine configuration parameters
            prompt_config: Optional prompt configuration (uses DEFAULT_PROMPT_CONFIG if not provided)
        """
        self.engine_params = engine_params
        self.prompt_config = prompt_config or DEFAULT_PROMPT_CONFIG
        self.agent = LMMAgent(
            engine_params=engine_params,
            system_prompt=self.prompt_config.supervisor_system_prompt
        )
        self.verification_history = []
    
    def reset(self):
        """Reset supervisor state"""
        self.agent.reset()
        self.agent.add_system_prompt(self.prompt_config.supervisor_system_prompt)
        self.verification_history = []
    
    def verify_step(
        self,
        planned_action: str,
        execution_result: Dict,
        before_screenshot: bytes,
        after_screenshot: bytes,
        expected_outcome: str = ""
    ) -> Dict:
        """
        Verify if a step's execution resulted in the expected state change
        
        Args:
            planned_action: What action was planned
            execution_result: Result from executor
            before_screenshot: Screenshot before action
            after_screenshot: Screenshot after action
            expected_outcome: Expected outcome from planner
            
        Returns:
            Verification result dictionary
        """
        # Check for execution failures first
        if execution_result.get("status") == "failure":
            return {
                "verification": "EXECUTION_FAILURE",
                "result": "FAIL",
                "reason": execution_result.get("reason", "Action failed to execute"),
                "details": "The executor could not complete the planned action"
            }
        
        if execution_result.get("status") == "error":
            return {
                "verification": "EXECUTION_FAILURE",
                "result": "FAIL",
                "reason": execution_result.get("error", "Execution error"),
                "details": "An error occurred during execution"
            }
        
        # Build verification prompt from config
        prompt = self.prompt_config.supervisor_step_verification_prompt_template.format(
            planned_action=planned_action,
            expected_outcome=expected_outcome
        )
        
        self.agent.add_message(
            text_content=prompt,
            image_content=before_screenshot,
            role="user"
        )
        self.agent.add_message(
            text_content="After screenshot:",
            image_content=after_screenshot,
            role="user"
        )
        
        # Get verification from LLM
        response = call_llm_safe(self.agent, temperature=0.1)
        logger.info(f"Supervisor verification: {response}")
        
        # Parse verification result
        verification_result = self._parse_verification(response)
        verification_result["response"] = response
        
        self.verification_history.append({
            "planned_action": planned_action,
            "execution_result": execution_result,
            "verification": verification_result
        })
        
        return verification_result
    
    def verify_final_state(
        self,
        test_case: str,
        final_screenshot: bytes,
        execution_history: list
    ) -> Dict:
        """
        Verify the final state of the test case
        
        Args:
            test_case: Test case description
            final_screenshot: Final screenshot after all steps
            execution_history: History of all executed steps
            
        Returns:
            Final verification result
        """
        # Build final verification prompt from config
        prompt = self.prompt_config.supervisor_final_verification_prompt_template.format(
            test_case=test_case,
            execution_history=self._format_execution_history(execution_history)
        )
        
        self.agent.add_message(
            text_content=prompt,
            image_content=final_screenshot,
            role="user"
        )
        
        response = call_llm_safe(self.agent, temperature=0.1)
        logger.info(f"Supervisor final verification: {response}")
        
        # Parse final result
        final_result = self._parse_final_result(response)
        final_result["response"] = response
        
        return final_result
    
    def verify_assertion(
        self,
        assertion_description: str,
        screenshot: bytes
    ) -> Dict:
        """
        Verify a specific assertion
        
        Args:
            assertion_description: Description of what to verify (e.g., "icon is red")
            screenshot: Screenshot to check
            
        Returns:
            Assertion verification result
        """
        # Build assertion prompt from config
        prompt = self.prompt_config.supervisor_assertion_prompt_template.format(
            assertion_description=assertion_description
        )
        
        self.agent.add_message(
            text_content=prompt,
            image_content=screenshot,
            role="user"
        )
        
        response = call_llm_safe(self.agent, temperature=0.1)
        logger.info(f"Supervisor assertion check: {response}")
        
        # Parse assertion result
        assertion_result = self._parse_assertion(response)
        assertion_result["response"] = response
        
        return assertion_result
    
    def _parse_verification(self, response: str) -> Dict:
        """Parse verification response from LLM for a single step"""
        response_lower = response.lower()
        
        step_part = response
        if "final test result" in response_lower or "final verdict" in response_lower:
            # Take only the part before "Final Test Result" or "Final Verdict"
            parts = re.split(r"(?i)final (test result|verdict)", response)
            if len(parts) > 0:
                step_part = parts[0]
        
        step_part_lower = step_part.lower()
        
        result = {
            "verification": "UNKNOWN",
            "result": "UNKNOWN",
            "reason": response[:200],
            "details": response
        }
        
        # Check for execution failure (this specific action failed)
        if any(keyword in step_part_lower for keyword in ["execution failure", "could not execute", "action failed", "element not found"]):
            result["verification"] = "EXECUTION_FAILURE"
            result["result"] = "FAIL"

        elif any(keyword in step_part_lower for keyword in ["assertion failed", "condition not met", "wrong", "incorrect"]) and "not achieved yet" not in step_part_lower:
            result["verification"] = "ASSERTION_FAILURE"
            result["result"] = "FAIL"
        
        # Check for success (this step worked)
        elif any(keyword in step_part_lower for keyword in ["result: pass", "passed", "action worked", "successfully", "correct"]):
            result["verification"] = "SUCCESS"
            result["result"] = "PASS"
        
        return result
    
    def _parse_final_result(self, response: str) -> Dict:
        """Parse final test result from LLM"""
        response_lower = response.lower()
        
        result = {
            "result": "UNKNOWN",
            "reason": response[:200],
            "details": response
        }
        
        if any(keyword in response_lower for keyword in ["pass", "success", "completed", "achieved"]):
            result["result"] = "PASS"
        elif any(keyword in response_lower for keyword in ["fail", "failed", "not completed", "not achieved"]):
            result["result"] = "FAIL"
        
        return result
    
    def _parse_assertion(self, response: str) -> Dict:
        """Parse assertion verification result"""
        response_lower = response.lower()
        
        result = {
            "assertion_passed": False,
            "observation": response[:200],
            "details": response
        }
        
        if any(keyword in response_lower for keyword in ["true", "correct", "matches", "verified", "yes"]):
            result["assertion_passed"] = True
        
        return result
    
    def _format_execution_history(self, execution_history: list) -> str:
        """Format execution history for prompt"""
        formatted = ""
        for i, step in enumerate(execution_history, 1):
            formatted += f"\nStep {i}:\n"
            formatted += f"  Action: {step.get('planned_action', 'N/A')}\n"
            formatted += f"  Execution: {step.get('execution_result', {}).get('status', 'N/A')}\n"
            if step.get('verification'):
                formatted += f"  Verification: {step.get('verification', {}).get('result', 'N/A')}\n"
        return formatted
    
    def get_test_summary(self) -> Dict:
        """Get summary of all verifications"""
        total_steps = len(self.verification_history)
        passed_steps = sum(1 for v in self.verification_history 
                          if v.get("verification", {}).get("result") == "PASS")
        failed_steps = total_steps - passed_steps
        
        execution_failures = sum(1 for v in self.verification_history
                                if v.get("verification", {}).get("verification") == "EXECUTION_FAILURE")
        assertion_failures = sum(1 for v in self.verification_history
                                if v.get("verification", {}).get("verification") == "ASSERTION_FAILURE")
        
        return {
            "total_steps": total_steps,
            "passed_steps": passed_steps,
            "failed_steps": failed_steps,
            "execution_failures": execution_failures,
            "assertion_failures": assertion_failures,
            "history": self.verification_history
        }

