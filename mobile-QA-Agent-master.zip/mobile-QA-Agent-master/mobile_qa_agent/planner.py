"""
Planner Agent - Breaks down test cases into actionable steps
"""

import logging
from typing import Dict, List, Optional
from gui_agents.s3.core.mllm import LMMAgent
from gui_agents.s3.utils.common_utils import call_llm_safe
from config import DEFAULT_PROMPT_CONFIG

logger = logging.getLogger("mobile_qa_agent")


class PlannerAgent:
    """Planner agent that breaks down test cases into executable steps"""
    
    def __init__(self, engine_params: Dict, prompt_config=None):
        """
        Initialize Planner agent
        
        Args:
            engine_params: LLM engine configuration parameters
            prompt_config: Optional prompt configuration (uses DEFAULT_PROMPT_CONFIG if not provided)
        """
        self.engine_params = engine_params
        self.prompt_config = prompt_config or DEFAULT_PROMPT_CONFIG
        self.agent = LMMAgent(
            engine_params=engine_params,
            system_prompt=self.prompt_config.planner_system_prompt
        )
        self.current_plan = []
        self.step_history = []
    
    def reset(self):
        """Reset planner state"""
        self.agent.reset()
        self.agent.add_system_prompt(self.prompt_config.planner_system_prompt)
        self.current_plan = []
        self.step_history = []
    
    def plan(self, test_case: str, current_screenshot: Optional[bytes] = None) -> List[Dict]:
        """
        Create a plan for executing the test case
        
        Args:
            test_case: Description of the test case
            current_screenshot: Optional screenshot of current state
            
        Returns:
            List of planned steps, each with action description and expected outcome
        """
        self.reset()
        
        # Build planning prompt from config
        prompt = self.prompt_config.planner_planning_prompt_template.format(
            test_case=test_case
        )
        
        # Add screenshot if provided
        if current_screenshot:
            self.agent.add_message(
                text_content=prompt,
                image_content=current_screenshot,
                role="user"
            )
        else:
            self.agent.add_message(prompt, role="user")
        
        # Get plan from LLM
        response = call_llm_safe(self.agent, temperature=0.3)
        logger.info(f"Planner response: {response}")
        
        plan_steps = self._parse_plan(response)
        self.current_plan = plan_steps
        self.step_history.append({"test_case": test_case, "plan": plan_steps})
        
        return plan_steps
    
    def _parse_plan(self, response: str) -> List[Dict]:
        """
        Parse LLM response into structured plan steps
        
        Args:
            response: LLM response text
            
        Returns:
            List of step dictionaries
        """
        steps = []
        lines = response.split('\n')
        
        current_step = None
        for line in lines:
            line = line.strip()
            if not line:
                continue
            
            # Look for step markers
            if any(marker in line.lower() for marker in ['step', 'action', '1.', '2.', '3.', '4.', '5.']):
                if current_step:
                    steps.append(current_step)
                current_step = {
                    "description": line,
                    "expected_outcome": ""
                }
            elif current_step:
                if any(keyword in line.lower() for keyword in ['expected', 'outcome', 'should', 'will']):
                    current_step["expected_outcome"] += line + " "
                else:
                    current_step["description"] += " " + line
        
        if current_step:
            steps.append(current_step)
        
        # If parsing fails, create a simple single-step plan
        if not steps:
            steps = [{
                "description": response[:200],
                "expected_outcome": "Execute the test case as described"
            }]
        
        return steps
    
    def get_next_step(self, step_index: int) -> Optional[Dict]:
        """Get the next step from the current plan"""
        if step_index < len(self.current_plan):
            return self.current_plan[step_index]
        return None
    
    def update_plan(self, feedback: str):
        """Update plan based on feedback (e.g., if a step failed)"""
        prompt = self.prompt_config.planner_update_prompt_template.format(
            feedback=feedback
        )
        self.agent.add_message(prompt, role="user")
        response = call_llm_safe(self.agent, temperature=0.3)
        logger.info(f"Plan update: {response}")
        return response

