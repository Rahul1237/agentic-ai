"""
Android Grounding Agent - Handles ADB commands for mobile device interaction
Similar to OSWorldACI but adapted for Android/ADB
"""

import re
import subprocess
import logging
from typing import Dict, List, Optional

from gui_agents.s3.core.mllm import LMMAgent
from gui_agents.s3.utils.common_utils import call_llm_safe

logger = logging.getLogger("mobile_qa_agent")


# Agent action decorator
def agent_action(func):
    func.is_agent_action = True
    return func


class AndroidACI:
    """Android Action Command Interface - Grounds natural language actions to ADB commands"""
    
    def __init__(
        self,
        device_id: Optional[str] = None,
        screen_width: int = 1344,
        screen_height: int = 2992,
        engine_params_for_grounding: Dict = None,
    ):
        self.device_id = device_id
        self.width = screen_width
        self.height = screen_height
        self.obs = None

        if engine_params_for_grounding:
            self.grounding_model = LMMAgent(engine_params_for_grounding)
            self.engine_params_for_grounding = engine_params_for_grounding
            self.grounding_width = engine_params_for_grounding.get("grounding_width", 1920)
            self.grounding_height = engine_params_for_grounding.get("grounding_height", 1080)
        else:
            self.grounding_model = None
            self.grounding_width = 1920
            self.grounding_height = 1080
    
    def _build_adb_command(self, command: str) -> List[str]:
        """Build ADB command with optional device ID"""
        if self.device_id:
            return ["adb", "-s", self.device_id] + command.split()
        return ["adb"] + command.split()
    
    def _run_adb_command(self, command: str) -> Dict:
        """Execute ADB command and return result"""
        try:
            cmd = self._build_adb_command(command)
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=30
            )
            return {
                "status": "success" if result.returncode == 0 else "error",
                "returncode": result.returncode,
                "output": result.stdout,
                "error": result.stderr
            }
        except subprocess.TimeoutExpired:
            return {"status": "error", "error": "Command timeout"}
        except Exception as e:
            logger.error(f"Error running ADB command: {e}")
            return {"status": "error", "error": str(e)}
    
    def assign_screenshot(self, obs: Dict):
        """Assign screenshot from observation"""
        self.obs = obs
    
    def generate_coords(self, ref_expr: str, obs: Dict) -> List[int]:
        """Generate coordinates using grounding model"""
        if not self.grounding_model:
            raise ValueError("Grounding model not initialized")
        self.grounding_model.reset()

        prompt = f"Query:{ref_expr}\nOutput only the coordinate of one point in your response.\n"
        self.grounding_model.add_message(
            text_content=prompt,
            image_content=obs["screenshot"],
            put_text_last=True
        )

        response = call_llm_safe(self.grounding_model)
        logger.info(f"RAW GROUNDING MODEL RESPONSE: {response}")
        
        if any(phrase in response.lower() for phrase in ["there are none", "not found", "cannot find", "no element"]):
            logger.warning(f"Grounding model could not find element: {ref_expr}")
            raise ValueError(f"Element not found: {ref_expr}. Grounding model response: {response}")
        
        # First try to find coordinates in parentheses
        coord_match = re.search(r'\((\d+),\s*(\d+)\)', response)
        if coord_match:
            coords = [int(coord_match.group(1)), int(coord_match.group(2))]
            logger.debug(f"Parsed coordinates (parentheses format): {coords}")
            return coords
        
        # Try to find two numbers separated by comma
        coord_match = re.search(r'(\d+),\s*(\d+)', response)
        if coord_match:
            coords = [int(coord_match.group(1)), int(coord_match.group(2))]
            logger.debug(f"Parsed coordinates (comma format): {coords}")
            return coords

        numericals = re.findall(r"\d+", response)
        if len(numericals) >= 2:
            coords = [int(numericals[0]), int(numericals[1])]
            logger.debug(f"Parsed coordinates (first two numbers): {coords}")
            return coords
        
        # If still no coordinates found, raise error with full response
        logger.error(f"Could not parse coordinates from response: {response}")
        raise ValueError(f"Could not parse coordinates from response: {response}")
    
    def resize_coordinates(self, coordinates: List[int]) -> List[int]:
        """
        Resize coordinates from grounding model output to actual screen dimensions.
        
        UI-TARS outputs coordinates relative to the INPUT image resolution, not a fixed 1920x1080.
        So if the screenshot is already 1344x2992, the coordinates are already correct.
        We only resize if coordinates seem to be in a different resolution.
        
        Args:
            coordinates: Coordinates from grounding model (may already be in device resolution)
            
        Returns:
            Coordinates in actual device screen resolution (e.g., 1344x2992)
        """
        x_original, y_original = coordinates
        
        # Check if coordinates are already in device range (within reasonable bounds)
        # If so, assume they're already correct and don't resize
        if (0 <= x_original <= self.width * 1.1 and 0 <= y_original <= self.height * 1.1):
            logger.info(
                f"Coordinates already in device range: ({x_original}, {y_original}) @ {self.width}x{self.height} (no resize needed)"
            )
            return [x_original, y_original]
        
        # If coordinates are larger, assume they're in grounding model's expected resolution (1920x1080)
        # and need to be resized down to device resolution
        x_resized = round(x_original * self.width / self.grounding_width)
        y_resized = round(y_original * self.height / self.grounding_height)
        
        # Clamp to device bounds
        x_resized = max(0, min(x_resized, self.width - 1))
        y_resized = max(0, min(y_resized, self.height - 1))
        
        logger.info(
            f"Resizing coordinates: ({x_original}, {y_original}) @ {self.grounding_width}x{self.grounding_height} "
            f"-> ({x_resized}, {y_resized}) @ {self.width}x{self.height}"
        )
        
        return [x_resized, y_resized]
    
    @agent_action
    def tap(self, element_description: str, x: Optional[int] = None, y: Optional[int] = None):
        """
        Tap on an element at coordinates or described location
        
        Args:
            element_description: Description of element to tap (used for grounding if x/y not provided)
            x: X coordinate (optional)
            y: Y coordinate (optional)
        """
        if x is not None and y is not None:
            coords = [x, y]
            logger.info(f"Using provided coordinates: ({x}, {y})")
        else:
            if not self.obs:
                raise ValueError("Screenshot must be assigned before grounding")
            logger.info(f"Grounding element: {element_description}")
            # Generate coordinates - UI-TARS outputs relative to input image resolution
            coords_grounding = self.generate_coords(element_description, self.obs)
            logger.info(f"Grounding model returned: {coords_grounding}")
            coords = self.resize_coordinates(coords_grounding)
        
        x, y = coords
        logger.info(f"Executing ADB tap at: ({x}, {y})")
        command = f"shell input tap {x} {y}"
        result = self._run_adb_command(command)
        return result
    
    @agent_action
    def swipe(
        self,
        start_description: str,
        end_description: Optional[str] = None,
        start_x: Optional[int] = None,
        start_y: Optional[int] = None,
        end_x: Optional[int] = None,
        end_y: Optional[int] = None,
        duration_ms: int = 300
    ):
        """
        Swipe/drag from start to end coordinates
        
        Args:
            start_description: Description of starting element
            end_description: Description of ending element
            start_x, start_y: Starting coordinates (optional)
            end_x, end_y: Ending coordinates (optional)
            duration_ms: Duration of swipe in milliseconds
        """
        if start_x is not None and start_y is not None:
            start_coords = [start_x, start_y]
        else:
            if not self.obs:
                raise ValueError("Screenshot must be assigned before grounding")
            start_coords = self.generate_coords(start_description, self.obs)
            start_coords = self.resize_coordinates(start_coords)
        
        if end_x is not None and end_y is not None:
            end_coords = [end_x, end_y]
        elif end_description:
            if not self.obs:
                raise ValueError("Screenshot must be assigned before grounding")
            end_coords = self.generate_coords(end_description, self.obs)
            end_coords = self.resize_coordinates(end_coords)
        else:
            raise ValueError("Either end_description or end_x/end_y must be provided")
        
        command = f"shell input swipe {start_coords[0]} {start_coords[1]} {end_coords[0]} {end_coords[1]} {duration_ms}"
        result = self._run_adb_command(command)
        return result
    
    @agent_action
    def type_text(
        self,
        text: str,
        element_description: Optional[str] = None,
        overwrite: bool = True
    ):
        """
        Type text into an input field. 
        
        IMPORTANT: On mobile, you MUST provide element_description to tap and focus the field first.
        The method will automatically: (1) tap the field to focus, (2) clear existing text if overwrite=True, (3) type new text.
        
        Args:
            text: Text to type
            element_description: REQUIRED description of input field to tap first (e.g., "Vault name input field", "text field labeled 'Name'")
            overwrite: If True, clears existing text before typing (default: True)
        """
        import time
        
        # First, tap on the input field if description is provided to focus it
        if element_description:
            if not self.obs:
                raise ValueError("Screenshot must be assigned before grounding")
            logger.info(f"Focusing input field: {element_description}")
            coords = self.generate_coords(element_description, self.obs)
            coords = self.resize_coordinates(coords)
            x, y = coords
            focus_result = self._run_adb_command(f"shell input tap {x} {y}")
            if focus_result.get("status") != "success":
                logger.warning(f"Failed to focus input field: {focus_result.get('error')}")
                return focus_result
            # Wait a bit for the field to focus
            time.sleep(0.5)
        
        # Clear existing text if overwrite is True
        if overwrite:
            # Try to select all text using keycombination (Ctrl+A) for Android 13+
            # Key codes: 113=Ctrl, 29=A
            select_result = self._run_adb_command("shell input keycombination 113 29")
            time.sleep(0.3)
            
            # Backspace to clear selected text
            clear_result = self._run_adb_command("shell input keyevent 67")  # Backspace
            time.sleep(0.2)
            
            # If selection failed, try multiple backspaces as fallback
            if select_result.get("status") != "success":
                logger.info("keycombination not supported, using multiple backspaces to clear field")
                # Send multiple backspaces to clear field (reasonable limit for typical inputs)
                for _ in range(15):
                    self._run_adb_command("shell input keyevent 67")
                    time.sleep(0.05)
            
            logger.info("Text clearing completed")
        
        # Type the text (ADB input text requires spaces as %s)
        text_encoded = text.replace(" ", "%s")
        type_result = self._run_adb_command(f'shell input text "{text_encoded}"')
        
        if type_result.get("status") == "success":
            logger.info(f"Successfully typed text: {text}")
            return {"status": "success", "action": "type_text", "text": text}
        else:
            logger.error(f"Failed to type text: {text}, error: {type_result.get('error')}")
            return type_result
    
    @agent_action
    def press_key(self, key_code: int):
        """
        Press a specific key
        
        Args:
            key_code: Android key code (e.g., 66 for Enter, 4 for Back, 3 for Home)
        """
        command = f"shell input keyevent {key_code}"
        result = self._run_adb_command(command)
        return result
    
    @agent_action
    def back(self):
        """Press the back button (key code 4)"""
        return self.press_key(4)
    
    @agent_action
    def home(self):
        """Press the home button (key code 3)"""
        return self.press_key(3)
    
    @agent_action
    def enter(self):
        """Press the enter key (key code 66)"""
        return self.press_key(66)
    
    @agent_action
    def select_all(self):
        """Select all text in focused field (Ctrl+A)"""
        command = "shell input keycombination 113 29"  # Ctrl+A
        result = self._run_adb_command(command)
        return result
    
    @agent_action
    def backspace(self):
        """Press backspace (key code 67)"""
        return self.press_key(67)
    
    @agent_action
    def wait(self, seconds: float):
        """Wait for specified time (returns wait command string for execution)"""
        return f"WAIT:{seconds}"
    
    @agent_action
    def done(self):
        """Signal task completion"""
        return "DONE"
    
    @agent_action
    def fail(self, reason: str = ""):
        """Signal task failure"""
        return f"FAIL:{reason}"
    
    def take_screenshot(self) -> bytes:
        """Take a screenshot and return as bytes"""
        command = "exec-out screencap -p"
        cmd = self._build_adb_command(command)
        try:
            result = subprocess.run(
                cmd,
                capture_output=True,
                timeout=10
            )
            if result.returncode == 0:
                return result.stdout
            else:
                raise ValueError(f"Screenshot failed: {result.stderr}")
        except Exception as e:
            logger.error(f"Error taking screenshot: {e}")
            raise
    
    def get_screen_size(self) -> Dict[str, int]:
        """Get the screen size of the device"""
        command = "shell wm size"
        result = self._run_adb_command(command)
        if result["status"] == "success":
            # Parse output like "Physical size: 1344x2992"
            match = re.search(r"(\d+)x(\d+)", result["output"])
            if match:
                return {"width": int(match.group(1)), "height": int(match.group(2))}
        return {"width": self.width, "height": self.height}

