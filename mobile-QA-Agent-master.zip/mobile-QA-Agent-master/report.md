# Framework Selection Report  
**Mobile QA Multi-Agent System**

## Executive Summary

After evaluating multiple agentic frameworks for mobile QA automation including **Google Agent Development Kit (ADK)**, **LangGraph**, and **Simular Agent S3** **Simular Agent S3** was selected as the foundation for this project.

The decision was driven by Agent S3’s **vision-grounded execution**, **long horizon robustness**, and **objective verification of task completion**, which are essential for mobile QA systems where correctness must be validated through observable UI state rather than agent intent or action logs.

While LangGraph provides an excellent abstraction for structuring multi agent workflows, it does not address the core challenges of mobile QA: **visual grounding, rollout evaluation, and hallucination-resistant verification**. Agent S3 uniquely solves these problems, making it the most reliable choice for production-grade mobile QA automation. It explain what steps it failed and why in detail.


---

## Objective

Select an agent framework capable of supporting a **multi-agent mobile QA system** that can:

- Execute **natural language QA test cases**
- Interact with the **Obsidian Android application**
- Reliably detect **step-level failures** and **assertion failures**
- Handle **long-horizon, high-variance UI workflows**
- Produce auditable pass/fail outcomes grounded in **visual evidence**

---

## Frameworks Evaluated

| Framework | Strengths | Limitations |
|---------|----------|------------|
| **Google Agent Development Kit (ADK)** | Lightweight orchestration, modular prompting, rapid prototyping | No native vision grounding; brittle over long-horizon tasks; assumes success based on intent |
| **LangGraph** | Explicit agent graphs; clean Supervisor–Planner–Executor modeling; flexible control flow | No built-in vision grounding; no rollout evaluation; correctness relies on single trajectory |
| **Simular Agent S3** | Vision-grounded execution; Behavior Best-of-N; long-horizon reliability; platform-agnostic | Higher compute cost; requires parallel rollout infrastructure |

---

## Why Not LangGraph Alone

LangGraph is a strong **agent orchestration framework**, particularly for modeling explicit control flow such as **Supervisor–Planner–Executor** systems. It excels at:

- Defining deterministic agent transitions
- Structuring reasoning loops
- Composing tool calls and agent roles

However, for **mobile QA**, orchestration alone is insufficient.

### Key Gaps for Mobile QA

- **No Vision Grounding:** LangGraph does not provide native mechanisms to verify UI state from screenshots.
- **Single-Trajectory Fragility:** A failed or hallucinated step irreversibly corrupts the outcome.
- **No Rollout Comparison:** Cannot distinguish partial success from real task completion.
- **No Visual Evidence:** Assertions depend on inferred intent rather than observed UI changes.

As a result, LangGraph-based agents often **assume correctness**, which is unacceptable in QA automation.

> In this project, LangGraph-style patterns were intentionally reimplemented at the architectural level, while relying on Agent S3 for grounding and verification.

---

## Why Simular Agent S3

I chose Simular Agent S3 for this mobile QA system for five critical reasons that directly address the unique challenges of mobile application testing:

### 1. Behavior Best-of-N (b-BoN): Reliability Over Intent

Agent S3's core innovation is executing multiple independent rollouts of the same task and evaluating them post-hoc. This approach:
- Prevents **hallucinated success** (e.g., assuming a tap succeeded when it did not)
- Detects **silent UI failures** that single-trajectory agents would miss
- Judges correctness based on **observable UI state**, not agent confidence or action logs

For mobile QA, this is essential because UI interactions can fail silently—a tap command may execute without error, but the intended UI element may not respond. Unlike ADK or LangGraph, which assume success based on action completion, Agent S3 verifies actual outcomes through visual comparison across multiple rollouts.

---

### 2. Vision-Grounded Execution

Unlike web applications with accessible DOMs, mobile applications lack stable APIs for programmatic verification. I needed a framework that operates directly on visual evidence. Agent S3's vision-grounded approach works with:

- Full screenshots of device states
- Before/after action image crops
- Visual evidence of UI transitions

This enables:
- **Fine-grained interaction verification** without relying on app internals
- **Robust detection** of missing or incorrect UI elements that would be invisible to API-based testing
- **Independence from accessibility heuristics** or app-specific instrumentation

This visual grounding is critical for mobile QA, where UI state changes are the only reliable indicator of successful interactions.

---

### 3. Multi-Agent Architecture Support

I needed a framework that supports explicit multi-agent roles without forcing a monolithic design. Agent S3 provides the grounding and verification capabilities while allowing custom architecture. My implementation uses:

- **Planner:** Breaks down test cases into actionable steps based on test intent and current UI state
- **Executor:** Executes UI actions via ADB commands (tap, swipe, type) using Agent S3's vision-grounded coordinate generation
- **Supervisor:** Verifies state transitions and validates assertions using Agent S3's judgment modules

By leveraging Agent S3's **grounding and judgment modules** as building blocks, I built a **custom Planner–Executor–Supervisor system** that demonstrates explicit multi-agent design patterns while maintaining the correctness guarantees that Agent S3 provides. This approach avoids reliance on a monolithic black-box agent while preserving the visual verification capabilities essential for QA.

---

### 4. Long-Horizon and High-Variance Robustness

Mobile QA test cases often require:
- **Multi-screen navigation** through complex app flows
- **Conditional flows** that depend on app state
- **UI latency, pop-ups, and unpredictable transitions** that break deterministic testing

Agent S3 is explicitly designed for these challenging conditions:
- **Independent rollouts** ensure that early-step failures don't invalidate the entire test
- **Variance analysis** surfaces flaky or unstable behavior patterns
- **Objective comparison** across multiple trajectories identifies the most reliable execution path

For the Obsidian Android app testing use case, this robustness is essential because mobile apps have higher variance than desktop applications due to system-level interruptions, keyboard overlays, and notification pop-ups.

---

### 5. Platform Agnosticism and Future Scalability

Agent S3's vision-grounded approach means a single implementation can operate across:

- Android emulators and physical devices (current use case)
- Desktop applications (Windows, macOS, Linux)
- Web browsers (via VNC)
- Any platform where screenshots are available

This platform agnosticism was an important consideration because it ensures the framework and architecture I built can scale beyond mobile testing to desktop and web applications without requiring fundamental re-engineering. The vision-grounded approach provides a unified abstraction layer across platforms.

---

## Trade-Offs

| Limitation | Rationale |
|-----------|-----------|
| Higher computational cost | Intentional trade-off for correctness and reliability |

---

## Final Decision

I selected **Simular Agent S3** as the foundation for this mobile QA system because it uniquely addresses the core requirements:

1. **Verifies real UI outcomes**, not inferred success critical for QA where correctness is non-negotiable
2. **Handles long-horizon, high-variance workflows** that are common in mobile app testing
3. **Exposes hallucinations and silent failures** through multi-rollout comparison
4. **Provides vision grounding** that mobile QA requires but LangGraph and ADK lack
5. **Supports explicit multi-agent architecture** while providing reliable grounding and verification
6. **Scales across platforms** without requiring platform-specific re-engineering

This decision reflects a deliberate choice: **correctness, auditability, and robustness** are more valuable than lightweight orchestration alone. For a QA automation system, false positives and missed failures are unacceptable, making Agent S3's rigorous verification approach the clear choice over frameworks that assume correctness based on action completion.

---

## References

- Simular Agent S3 – *Wide-Scaling Agents via Behavior Best-of-N*  
  https://arxiv.org/abs/2510.02250  
- OSWorld Benchmark  
  https://arxiv.org/abs/2404.07972  

---
