"""
QA Test Cases for Obsidian Mobile App Testing
"""

TEST_CASES = [
    {
        "id": "test_1",
        "name": "Create New Vault",
        "description": "Open Obsidian, create a new Vault named 'InternVault', and enter the vault.",
        "expected_result": "PASS",
        "notes": "Should successfully create and enter the vault"
    },
    {
        "id": "test_2",
        "name": "Create New Note",
        "description": "Create a new note titled 'Meeting Notes' and type the text 'Daily Standup' into the body.",
        "expected_result": "PASS",
        "notes": "Should successfully create note and add content"
    },
    {
        "id": "test_3",
        "name": "Verify Appearance Tab Color",
        "description": "Go to Settings and verify that the 'Appearance' tab icon is the color Red.",
        "expected_result": "FAIL",
        "notes": "Should detect that icon is monochrome/default theme color, not Red (ASSERTION_FAILURE)"
    },
    {
        "id": "test_4",
        "name": "Find Print to PDF Button",
        "description": "Find and click the 'Print to PDF' button in the main file menu.",
        "expected_result": "FAIL",
        "notes": "Should detect that button doesn't exist in mobile version (EXECUTION_FAILURE)"
    }
]

